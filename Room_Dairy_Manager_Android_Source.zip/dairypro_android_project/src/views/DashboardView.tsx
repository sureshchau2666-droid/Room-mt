/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { ExpenseItem, DairyCategory } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { ActiveTab } from '../components/Navbar';
import { 
  TrendingUp, 
  Receipt, 
  Users, 
  PlusCircle, 
  Calculator, 
  AlertCircle, 
  Calendar, 
  ArrowRight,
  Milk,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface DashboardViewProps {
  expenses: ExpenseItem[];
  currentMonth: string; // YYYY-MM
  setCurrentMonth: (m: string) => void;
  setActiveTab: (t: ActiveTab) => void;
  onQuickAdd: (category: DairyCategory) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  expenses,
  currentMonth,
  setCurrentMonth,
  setActiveTab,
  onQuickAdd,
}) => {
  const { t, language } = useLanguage();
  const { currentMember, isAdmin } = useAuth();

  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);

  // Filter monthly and today's expenses
  const monthlyExpenses = useMemo(() => {
    return expenses.filter((e) => e.date.startsWith(currentMonth));
  }, [expenses, currentMonth]);

  const todayExpenses = useMemo(() => {
    return expenses.filter((e) => e.date === todayStr);
  }, [expenses, todayStr]);

  // Aggregate stats
  const totalMonthlySpend = useMemo(() => {
    return monthlyExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [monthlyExpenses]);

  const categoryBreakdown = useMemo(() => {
    let milk = 0;
    let chhaas = 0;
    let curd = 0;

    monthlyExpenses.forEach((e) => {
      const amt = Number(e.amount) || 0;
      if (e.category === 'milk') milk += amt;
      else if (e.category === 'chhaas') chhaas += amt;
      else if (e.category === 'curd') curd += amt;
    });

    return { milk, chhaas, curd };
  }, [monthlyExpenses]);

  // Current member individual share calculation
  const myMonthlyShare = useMemo(() => {
    if (!currentMember) return 0;
    const memberName = currentMember.name;

    return monthlyExpenses.reduce((sum, e) => {
      if (e.usedBy && e.usedBy.includes(memberName) && e.usedBy.length > 0) {
        return sum + (Number(e.amount) / e.usedBy.length);
      }
      return sum;
    }, 0);
  }, [monthlyExpenses, currentMember]);

  const formatMonthName = (monthStr: string) => {
    const [y, m] = monthStr.split('-');
    const date = new Date(Number(y), Number(m) - 1, 1);
    return date.toLocaleDateString(language === 'gu' ? 'gu-IN' : 'en-US', {
      month: 'long',
      year: 'numeric',
    });
  };

  return (
    <div className="space-y-5 animate-fade-in pb-16">
      {/* Dairy Owner Direct Payment Notice */}
      <div className="rounded-2xl bg-gradient-to-r from-amber-500/20 via-amber-500/10 to-transparent border border-amber-500/40 p-3.5 flex items-start gap-3 shadow-sm">
        <div className="p-2 rounded-xl bg-amber-500 text-zinc-950 font-bold shrink-0 mt-0.5">
          <AlertCircle className="w-4 h-4" />
        </div>
        <div>
          <h4 className="text-xs md:text-sm font-bold text-amber-300">
            {language === 'gu' ? 'મહત્વની સૂચના: સીધી ડેરી ચુકવણી' : 'Notice: Direct Dairy Payment'}
          </h4>
          <p className="text-xs text-zinc-300 mt-0.5 leading-relaxed">
            {t('dairyDirectNotice')}
          </p>
        </div>
      </div>

      {/* Month Selector & Heading */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-zinc-100 tracking-tight">
            {t('dashboard')}
          </h2>
          <p className="text-xs text-zinc-400">
            {formatMonthName(currentMonth)} • ૫ સભ્યોનો રૂમ ડેરી હિસાબ
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-200">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <input
              type="month"
              value={currentMonth}
              onChange={(e) => setCurrentMonth(e.target.value)}
              className="bg-transparent text-xs text-amber-300 font-bold focus:outline-none cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Main Stats Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Total Dairy Spend */}
        <div className="relative overflow-hidden rounded-3xl bg-zinc-900/90 border border-zinc-800 p-5 shadow-lg group hover:border-amber-500/40 transition">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl group-hover:bg-amber-500/20 transition" />
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
              {t('totalDairySpend')}
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-black text-amber-400 tracking-tight">
            ₹{totalMonthlySpend.toFixed(2)}
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            {monthlyExpenses.length} {language === 'gu' ? 'કુલ એન્ટ્રીઓ આ મહિને' : 'entries recorded'}
          </p>
        </div>

        {/* My Personal Consumption */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-900 to-zinc-950 border border-amber-500/30 p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-amber-300 uppercase tracking-wider">
              {t('myConsumption')}
            </span>
            <div className="p-2 rounded-xl bg-amber-500 text-zinc-950 font-bold">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-black text-zinc-100 tracking-tight">
            ₹{myMonthlyShare.toFixed(2)}
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            {currentMember?.name} {language === 'gu' ? 'નો વાસ્તવિક હિસ્સો' : 'actual consumption'}
          </p>
        </div>

        {/* Today's Dairy */}
        <div className="relative overflow-hidden rounded-3xl bg-zinc-900/90 border border-zinc-800 p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
              {t('todayDairy')}
            </span>
            <div className="p-2 rounded-xl bg-zinc-800 text-amber-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-black text-zinc-200 tracking-tight">
            ₹{todayExpenses.reduce((s, e) => s + (Number(e.amount) || 0), 0).toFixed(2)}
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            {todayExpenses.length} {language === 'gu' ? 'આજની એન્ટ્રી' : 'entries today'}
          </p>
        </div>
      </div>

      {/* Category Breakdown Pill Bars */}
      <div className="rounded-3xl bg-zinc-900/60 border border-zinc-800/80 p-4 shadow-sm">
        <h3 className="text-xs font-bold text-zinc-300 uppercase tracking-wider mb-3">
          {language === 'gu' ? 'કેટેગરી મુજબ વપરાશ' : 'Monthly Category Breakdown'}
        </h3>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-3 rounded-2xl bg-zinc-850/80 border border-zinc-800">
            <span className="text-lg">🥛</span>
            <div className="text-xs font-semibold text-zinc-400 mt-1">{t('milk')}</div>
            <div className="text-sm md:text-base font-extrabold text-amber-400 mt-0.5">
              ₹{categoryBreakdown.milk.toFixed(0)}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-zinc-850/80 border border-zinc-800">
            <span className="text-lg">🍶</span>
            <div className="text-xs font-semibold text-zinc-400 mt-1">{t('chhaas')}</div>
            <div className="text-sm md:text-base font-extrabold text-amber-400 mt-0.5">
              ₹{categoryBreakdown.chhaas.toFixed(0)}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-zinc-850/80 border border-zinc-800">
            <span className="text-lg">🥣</span>
            <div className="text-xs font-semibold text-zinc-400 mt-1">{t('curd')}</div>
            <div className="text-sm md:text-base font-extrabold text-amber-400 mt-0.5">
              ₹{categoryBreakdown.curd.toFixed(0)}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div>
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-2.5">
          {t('quickActions')}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            onClick={() => onQuickAdd('milk')}
            className="flex items-center gap-2 p-3 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 hover:bg-zinc-850 active:scale-95 transition text-left"
          >
            <span className="text-xl">🥛</span>
            <div>
              <div className="text-xs font-bold text-zinc-200">{t('logMilk')}</div>
              <div className="text-[10px] text-zinc-400">{language === 'gu' ? 'દૂધ ઉમેરો' : 'Add Milk'}</div>
            </div>
          </button>

          <button
            onClick={() => onQuickAdd('chhaas')}
            className="flex items-center gap-2 p-3 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 hover:bg-zinc-850 active:scale-95 transition text-left"
          >
            <span className="text-xl">🍶</span>
            <div>
              <div className="text-xs font-bold text-zinc-200">{t('logChhaas')}</div>
              <div className="text-[10px] text-zinc-400">{language === 'gu' ? 'છાશ ઉમેરો' : 'Add Chhaas'}</div>
            </div>
          </button>

          <button
            onClick={() => onQuickAdd('curd')}
            className="flex items-center gap-2 p-3 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 hover:bg-zinc-850 active:scale-95 transition text-left"
          >
            <span className="text-xl">🥣</span>
            <div>
              <div className="text-xs font-bold text-zinc-200">{t('logCurd')}</div>
              <div className="text-[10px] text-zinc-400">{language === 'gu' ? 'દહીં ઉમેરો' : 'Add Curd'}</div>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('settlement')}
            className="flex items-center gap-2 p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 hover:bg-amber-500/25 active:scale-95 transition text-left"
          >
            <Calculator className="w-5 h-5 text-amber-400" />
            <div>
              <div className="text-xs font-bold text-amber-300">{t('settlement')}</div>
              <div className="text-[10px] text-amber-200/80">{language === 'gu' ? 'માસિક હિસાબ' : '5-Member Split'}</div>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Entries */}
      <div className="rounded-3xl bg-zinc-900/80 border border-zinc-800 p-4 md:p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-sm md:text-base text-zinc-100">
              {t('recentEntries')}
            </h3>
          </div>
          <button
            onClick={() => setActiveTab('expenses')}
            className="flex items-center gap-1 text-xs font-bold text-amber-400 hover:text-amber-300 transition"
          >
            <span>{language === 'gu' ? 'બધા જુઓ' : 'View All'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {monthlyExpenses.length === 0 ? (
          <div className="py-10 text-center text-zinc-500">
            <p className="text-xs">{t('noExpensesMonth')}</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {monthlyExpenses.slice(0, 5).map((expense) => {
              const categoryEmoji =
                expense.category === 'milk' ? '🥛' : expense.category === 'chhaas' ? '🍶' : '🥣';
              const categoryLabel = t(expense.category);

              return (
                <div
                  key={expense.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-zinc-850/60 border border-zinc-800/80 hover:border-zinc-700 transition"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center text-lg shrink-0">
                      {categoryEmoji}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs md:text-sm font-bold text-zinc-100 truncate">
                          {categoryLabel}
                        </h4>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                            expense.paymentType === 'paid'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {expense.paymentType === 'paid' ? t('paid') : t('udhar')}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        {expense.date} • {language === 'gu' ? 'વાપરનાર:' : 'Consumers:'}{' '}
                        {expense.usedBy.join(', ')} ({expense.usedBy.length})
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 ml-3">
                    <div className="text-sm md:text-base font-extrabold text-amber-400">
                      ₹{expense.amount}
                    </div>
                    <div className="text-[10px] text-zinc-400">
                      ₹{(expense.amount / expense.usedBy.length).toFixed(1)}/person
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
