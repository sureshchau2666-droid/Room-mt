/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type DairyCategory = 'milk' | 'chhaas' | 'curd';

export type PaymentType = 'paid' | 'udhar';

export type SettlementStatus = 'pending' | 'partially_paid' | 'paid';

export type UserRole = 'admin' | 'member';

export type Language = 'en' | 'gu';

export interface RoomMember {
  id: string; // strictly 'suresh' | 'ashvin' | 'ramesh' | 'prakash' | 'rajesh'
  name: string;
  nameGu: string;
  email: string;
  role: UserRole;
  phone?: string;
  active: boolean;
  avatarColor: string;
  uid?: string; // Firebase Auth UID linked when registered/logged in
  lastLogin?: number;
  hasPinConfigured?: boolean;
}

export interface MemberPrivateSecurity {
  memberId: string;
  pinHash: string;
  pinSalt: string;
  updatedAt: number;
}

export interface ExpenseItem {
  id: string;
  date: string; // YYYY-MM-DD
  category: DairyCategory;
  amount: number;
  paidBy: string; // Member name
  paymentType: PaymentType;
  usedBy: string[]; // Member names who consumed
  splitAmountPerPerson: number;
  notes?: string;
  createdBy: string; // Firebase Auth UID
  createdByName: string;
  createdAt: number;
  updatedAt?: number;
}

export interface MemberMonthlyConsumption {
  memberId: string;
  memberName: string;
  memberNameGu: string;
  milkAmount: number;
  chhaasAmount: number;
  curdAmount: number;
  totalAmount: number;
  paidAmount: number; // What the member has already cleared/paid to dairy
  udharAmount: number;
  dueAmount: number; // Remaining to pay to dairy owner
  status: SettlementStatus;
  settlementNotes?: string;
  lastUpdated?: number;
  updatedBy?: string;
}

export interface MonthlySettlementRecord {
  id: string; // e.g. 2026-11_suresh
  month: string; // YYYY-MM
  memberId: string;
  memberName: string;
  milkAmount: number;
  chhaasAmount: number;
  curdAmount: number;
  totalAmount: number;
  paidAmount: number;
  udharAmount: number;
  dueAmount: number;
  status: SettlementStatus;
  notes?: string;
  lastUpdated: number;
  updatedBy: string;
}

export interface AppNotification {
  id: string;
  title: string;
  titleGu: string;
  body: string;
  bodyGu: string;
  category: 'expense_added' | 'expense_edited' | 'expense_deleted' | 'settlement_updated' | 'system';
  createdAt: number;
  readBy: string[];
}

export const CANONICAL_MEMBERS: Omit<RoomMember, 'uid' | 'lastLogin' | 'hasPinConfigured'>[] = [
  {
    id: 'suresh',
    name: 'Suresh',
    nameGu: 'સુરેશ (એડમિન)',
    email: 'sureshchau2666@gmail.com',
    role: 'admin',
    active: true,
    avatarColor: '#EAB308', // Gold
  },
  {
    id: 'ashvin',
    name: 'Ashvin',
    nameGu: 'અશ્વિન',
    email: 'ashvin.room@gmail.com',
    role: 'member',
    active: true,
    avatarColor: '#38BDF8', // Sky
  },
  {
    id: 'ramesh',
    name: 'Ramesh',
    nameGu: 'રમેશ',
    email: 'ramesh.room@gmail.com',
    role: 'member',
    active: true,
    avatarColor: '#4ADE80', // Emerald
  },
  {
    id: 'prakash',
    name: 'Prakash',
    nameGu: 'પ્રકાશ',
    email: 'prakash.room@gmail.com',
    role: 'member',
    active: true,
    avatarColor: '#F472B6', // Rose
  },
  {
    id: 'rajesh',
    name: 'Rajesh',
    nameGu: 'રાજેશ',
    email: 'rajesh.room@gmail.com',
    role: 'member',
    active: true,
    avatarColor: '#A78BFA', // Purple
  },
];

export const ADMIN_EMAIL = 'sureshchau2666@gmail.com';
