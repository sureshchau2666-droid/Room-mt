/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Web Crypto SHA-256 PIN hashing with salt
export async function hashPin(pin: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(`${salt}:${pin}:room_dairy_manager_secure`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function generateSalt(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

// PIN brute-force attempt manager
const LOCKOUT_KEY = 'rdm_pin_lockout';
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 5 * 60 * 1000; // 5 minutes

interface LockoutState {
  attempts: number;
  lockedUntil: number | null;
}

export function getPinLockoutState(): { isLocked: boolean; remainingSeconds: number; attemptsLeft: number } {
  try {
    const raw = localStorage.getItem(LOCKOUT_KEY);
    if (!raw) return { isLocked: false, remainingSeconds: 0, attemptsLeft: MAX_ATTEMPTS };

    const state: LockoutState = JSON.parse(raw);
    const now = Date.now();

    if (state.lockedUntil && state.lockedUntil > now) {
      const remainingSeconds = Math.ceil((state.lockedUntil - now) / 1000);
      return { isLocked: true, remainingSeconds, attemptsLeft: 0 };
    }

    if (state.lockedUntil && state.lockedUntil <= now) {
      // Lockout expired, reset
      localStorage.removeItem(LOCKOUT_KEY);
      return { isLocked: false, remainingSeconds: 0, attemptsLeft: MAX_ATTEMPTS };
    }

    const attemptsLeft = Math.max(0, MAX_ATTEMPTS - state.attempts);
    return { isLocked: false, remainingSeconds: 0, attemptsLeft };
  } catch {
    return { isLocked: false, remainingSeconds: 0, attemptsLeft: MAX_ATTEMPTS };
  }
}

export function recordFailedPinAttempt(): { isLocked: boolean; remainingSeconds: number; attemptsLeft: number } {
  try {
    const raw = localStorage.getItem(LOCKOUT_KEY);
    const state: LockoutState = raw ? JSON.parse(raw) : { attempts: 0, lockedUntil: null };
    state.attempts += 1;

    if (state.attempts >= MAX_ATTEMPTS) {
      state.lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
      localStorage.setItem(LOCKOUT_KEY, JSON.stringify(state));
      return { isLocked: true, remainingSeconds: LOCKOUT_DURATION_MS / 1000, attemptsLeft: 0 };
    }

    localStorage.setItem(LOCKOUT_KEY, JSON.stringify(state));
    return { isLocked: false, remainingSeconds: 0, attemptsLeft: MAX_ATTEMPTS - state.attempts };
  } catch {
    return { isLocked: false, remainingSeconds: 0, attemptsLeft: 0 };
  }
}

export function resetPinAttempts(): void {
  try {
    localStorage.removeItem(LOCKOUT_KEY);
  } catch {
    // Ignore storage errors
  }
}
