/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useLanguage } from '../context/LanguageContext';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { language } = useLanguage();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 md:left-auto md:right-6 md:w-auto z-50 flex items-center justify-between gap-3 rounded-xl bg-amber-500/95 text-zinc-950 px-4 py-2.5 text-xs font-semibold shadow-xl backdrop-blur-md border border-amber-400">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0 animate-pulse" />
        <span>
          {language === 'gu'
            ? 'ઑફલાઇન મોડ: સ્થાનિક ડેટા ઉપલબ્ધ છે. ઇન્ટરનેટ આવતાં આપોઆપ સિંક થશે.'
            : 'Offline Mode: Local cached records available. Changes will sync when online.'}
        </span>
      </div>
    </div>
  );
};
