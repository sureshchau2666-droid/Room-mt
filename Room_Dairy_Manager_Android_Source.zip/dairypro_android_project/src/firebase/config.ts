/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { 
  getFirestore, 
  initializeFirestore, 
  persistentLocalCache, 
  persistentMultipleTabManager, 
  Firestore 
} from 'firebase/firestore';

export interface FirebaseClientConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
  measurementId?: string;
}

const LOCAL_STORAGE_FIREBASE_KEY = 'rdm_custom_firebase_config';

export function getSavedFirebaseConfig(): FirebaseClientConfig | null {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_FIREBASE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // Ignore storage parse error
  }
  return null;
}

export function saveCustomFirebaseConfig(config: FirebaseClientConfig): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_FIREBASE_KEY, JSON.stringify(config));
  } catch {
    // Ignore storage write error
  }
}

export function clearCustomFirebaseConfig(): void {
  try {
    localStorage.removeItem(LOCAL_STORAGE_FIREBASE_KEY);
  } catch {
    // Ignore storage delete error
  }
}

export function resolveFirebaseConfig(): FirebaseClientConfig {
  const saved = getSavedFirebaseConfig();
  if (saved && saved.apiKey && saved.projectId === 'room-fdba7') {
    return saved;
  }

  return {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'room-fdba7.firebaseapp.com',
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'room-fdba7',
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'room-fdba7.appspot.com',
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '722320561512',
    appId: import.meta.env.VITE_FIREBASE_APP_ID || '',
  };
}

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

export function initFirebase(): { app: FirebaseApp | null; auth: Auth | null; db: Firestore | null } {
  const config = resolveFirebaseConfig();

  // If no apiKey is available yet, return null instances
  if (!config.apiKey || config.apiKey.trim() === '') {
    return { app: null, auth: null, db: null };
  }

  try {
    if (!getApps().length) {
      app = initializeApp(config);
      auth = getAuth(app);
      
      // Initialize Firestore with persistent multi-tab local cache for offline PWA
      try {
        db = initializeFirestore(app, {
          localCache: persistentLocalCache({
            tabManager: persistentMultipleTabManager(),
          }),
        });
      } catch {
        db = getFirestore(app);
      }
    } else {
      app = getApp();
      auth = getAuth(app);
      db = getFirestore(app);
    }
  } catch (err) {
    console.error('Failed to initialize Firebase with existing room-fdba7 config:', err);
    return { app: null, auth: null, db: null };
  }

  return { app, auth, db };
}

// Initial invocation
const initialized = initFirebase();
app = initialized.app;
auth = initialized.auth;
db = initialized.db;

export { app, auth, db };

export function isFirebaseConfigured(): boolean {
  const config = resolveFirebaseConfig();
  return Boolean(config.apiKey && config.apiKey.trim().length > 10 && config.projectId === 'room-fdba7');
}
