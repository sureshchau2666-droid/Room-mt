/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useLanguage } from '../context/LanguageContext';
import { Download, Share2, X, Smartphone, CheckCircle } from 'lucide-react';

export const PWAInstallBanner: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { language } = useLanguage();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (isInstalled || dismissed) {
    return null;
  }

  if (!isInstallable && !isIOS) {
    return null;
  }

  return (
    <>
      <div className="no-print mx-4 mb-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-zinc-900 to-amber-500/10 border border-amber-500/30 p-3.5 shadow-lg backdrop-blur-sm">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-black flex items-center justify-center font-bold shadow-md shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-400">
                {language === 'gu' ? 'મોબાઈલમાં એપ ઇન્સ્ટોલ કરો' : 'Install Room Dairy App'}
              </h4>
              <p className="text-xs text-zinc-300">
                {language === 'gu'
                  ? 'હોમ સ્ક્રીન પરથી ૧-ક્લિકમાં ખોલો અને ઑફલાઇન પણ વાપરો'
                  : 'Fast access from home screen & works offline'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isInstallable && (
              <button
                onClick={install}
                className="flex items-center gap-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 px-3.5 py-1.5 text-xs font-bold text-zinc-950 transition shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{language === 'gu' ? 'ઇન્સ્ટોલ' : 'Install'}</span>
              </button>
            )}

            {isIOS && (
              <button
                onClick={() => setShowIOSGuide(true)}
                className="flex items-center gap-1.5 rounded-xl border border-amber-500/50 bg-amber-500/20 hover:bg-amber-500/30 px-3.5 py-1.5 text-xs font-semibold text-amber-300 transition"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{language === 'gu' ? 'iPhone પર ઉમેરો' : 'Add to iPhone'}</span>
              </button>
            )}

            <button
              onClick={() => setDismissed(true)}
              className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              aria-label="Dismiss"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-zinc-900 border border-amber-500/40 p-6 shadow-2xl text-zinc-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center text-zinc-950 font-bold">
                  🍎
                </div>
                <h3 className="text-base font-bold text-amber-400">
                  {language === 'gu' ? 'iPhone / iPad પર ઇન્સ્ટોલ' : 'Install on iPhone / iPad'}
                </h3>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="p-1 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-zinc-300 leading-relaxed">
              <div className="flex items-start gap-3 p-2.5 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-zinc-950">
                  1
                </span>
                <p>
                  {language === 'gu'
                    ? 'Safari બ્રાઉઝરના નીચેના ભાગમાં આપેલ "Share" (શેર) બટન પર ટેપ કરો.'
                    : 'Tap the "Share" button at the bottom of the Safari browser.'}
                </p>
              </div>

              <div className="flex items-start gap-3 p-2.5 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-zinc-950">
                  2
                </span>
                <p>
                  {language === 'gu'
                    ? 'મેનુમાં નીચે સ્ક્રોલ કરી "Add to Home Screen" (હોમ સ્ક્રીન પર ઉમેરો) પસંદ કરો.'
                    : 'Scroll down and tap "Add to Home Screen".'}
                </p>
              </div>

              <div className="flex items-start gap-3 p-2.5 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-zinc-950">
                  3
                </span>
                <p>
                  {language === 'gu'
                    ? 'ઉપર જમણી બાજુ "Add" પર ક્લિક કરો. એપ તમારા ફોનમાં આવી જશે!'
                    : 'Tap "Add" in the top right corner. The app is ready on your home screen!'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full rounded-xl bg-amber-500 py-2.5 text-xs font-bold text-zinc-950 hover:bg-amber-400 transition"
            >
              {language === 'gu' ? 'સમજાઈ ગયું' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
