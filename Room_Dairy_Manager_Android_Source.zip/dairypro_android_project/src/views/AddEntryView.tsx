/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { DairyCategory, PaymentType, CANONICAL_MEMBERS } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { addExpense } from '../services/expenseService';
import { 
  PlusCircle, 
  Check, 
  Users, 
  Calendar, 
  FileText, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles 
} from 'lucide-react';

interface AddEntryViewProps {
  initialCategory?: DairyCategory;
  onSuccess: () => void;
}

export const AddEntryView: React.FC<AddEntryViewProps> = ({
  initialCategory = 'milk',
  onSuccess,
}) => {
  const { t, language } = useLanguage();
  const { currentMember, currentUser } = useAuth();

  const [category, setCategory] = useState<DairyCategory>(initialCategory);
  const [amount, setAmount] = useState<string>('');
  const [paidBy, setPaidBy] = useState<string>(currentMember?.name || 'Suresh');
  const [paymentType, setPaymentType] = useState<PaymentType>('paid');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [usedBy, setUsedBy] = useState<string[]>(CANONICAL_MEMBERS.map((m) => m.name));
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [successToast, setSuccessToast] = useState<string>('');

  useEffect(() => {
    if (initialCategory) {
      setCategory(initialCategory);
    }
  }, [initialCategory]);

  useEffect(() => {
    if (currentMember?.name) {
      setPaidBy(currentMember.name);
    }
  }, [currentMember]);

  // Adjust default consumers based on known consumption patterns
  const handleCategoryChange = (cat: DairyCategory) => {
    setCategory(cat);
    if (cat === 'milk') {
      // By default for milk/morning tea, Ashvin usually doesn't drink morning tea/milk
      setUsedBy(['Suresh', 'Ramesh', 'Prakash', 'Rajesh']);
    } else {
      // For chhaas and curd, everyone generally shares
      setUsedBy(CANONICAL_MEMBERS.map((m) => m.name));
    }
  };

  const toggleConsumer = (name: string) => {
    if (usedBy.includes(name)) {
      if (usedBy.length === 1) {
        setErrorMessage(t('validationConsumers'));
        return;
      }
      setUsedBy(usedBy.filter((n) => n !== name));
    } else {
      setUsedBy([...usedBy, name]);
    }
    setErrorMessage('');
  };

  // Preset helpers
  const applyPreset = (preset: 'all' | 'no_ashvin' | 'evening' | 'curd') => {
    setErrorMessage('');
    if (preset === 'all' || preset === 'evening') {
      setUsedBy(CANONICAL_MEMBERS.map((m) => m.name));
    } else if (preset === 'no_ashvin') {
      setUsedBy(['Suresh', 'Ramesh', 'Prakash', 'Rajesh']);
    } else if (preset === 'curd') {
      setUsedBy(CANONICAL_MEMBERS.map((m) => m.name));
    }
  };

  const addAmountPreset = (increment: number) => {
    const current = Number(amount) || 0;
    setAmount(String(current + increment));
  };

  const numAmount = Number(amount) || 0;
  const splitPerPerson = usedBy.length > 0 ? (numAmount / usedBy.length).toFixed(2) : '0.00';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!numAmount || numAmount <= 0) {
      setErrorMessage(t('validationAmount'));
      return;
    }

    if (usedBy.length === 0) {
      setErrorMessage(t('validationConsumers'));
      return;
    }

    setIsSubmitting(true);
    try {
      await addExpense({
        date,
        category,
        amount: numAmount,
        paidBy,
        paymentType,
        usedBy,
        notes,
        createdBy: currentUser?.uid || 'user',
        createdByName: currentMember?.name || paidBy || 'Member',
      });

      setSuccessToast(
        language === 'gu'
          ? `₹${numAmount} ની એન્ટ્રી સફળતાપૂર્વક સાચવવામાં આવી!`
          : `Expense of ₹${numAmount} recorded successfully!`
      );

      // Reset form
      setAmount('');
      setNotes('');
      setTimeout(() => {
        setSuccessToast('');
        onSuccess();
      }, 1200);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Failed to save expense');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-5 animate-fade-in pb-16">
      {/* Header */}
      <div>
        <h2 className="text-xl md:text-2xl font-black text-zinc-100 tracking-tight">
          {t('newExpenseTitle')}
        </h2>
        <p className="text-xs text-zinc-400">
          {language === 'gu'
            ? 'ડેરી ખર્ચ ઉમેરો અને વાપરનાર સભ્યો વચ્ચે આપોઆપ સમાન ભાગ કરો'
            : 'Log expense and accurately divide among active consumers'}
        </p>
      </div>

      {successToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{successToast}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Category Selection Cards */}
        <div>
          <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2">
            {t('selectCategory')}
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            {[
              { id: 'milk' as DairyCategory, label: t('milk'), emoji: '🥛', note: 'Tea / Milk' },
              { id: 'chhaas' as DairyCategory, label: t('chhaas'), emoji: '🍶', note: 'Evening' },
              { id: 'curd' as DairyCategory, label: t('curd'), emoji: '🥣', note: 'Cooking' },
            ].map((cat) => {
              const isSelected = category === cat.id;
              return (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => handleCategoryChange(cat.id)}
                  className={`p-3.5 rounded-2xl border text-center transition active:scale-95 flex flex-col items-center ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-lg shadow-amber-500/10 ring-2 ring-amber-500/30'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <span className="text-2xl mb-1">{cat.emoji}</span>
                  <span className="text-xs font-bold">{cat.label}</span>
                  <span className="text-[10px] text-zinc-400 mt-0.5">{cat.note}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Amount Input & Keypad Presets */}
        <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider">
              {t('amount')}
            </label>
            {numAmount > 0 && (
              <span className="text-xs font-extrabold text-amber-400">
                ₹{numAmount.toFixed(0)}
              </span>
            )}
          </div>

          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl font-bold text-amber-400">
              ₹
            </span>
            <input
              type="number"
              min="1"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl pl-10 pr-4 py-3 text-2xl font-black text-amber-300 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 transition"
              required
            />
          </div>

          {/* Quick preset increments */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-zinc-400 mr-1">{language === 'gu' ? 'ઝડપી રકમ:' : 'Quick add:'}</span>
            {[10, 20, 30, 40, 50, 100].map((inc) => (
              <button
                type="button"
                key={inc}
                onClick={() => addAmountPreset(inc)}
                className="px-2.5 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-bold text-amber-300 transition active:scale-95"
              >
                +{inc}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setAmount('')}
              className="px-2 py-1 rounded-xl bg-zinc-800 text-[10px] font-semibold text-zinc-400 hover:text-white"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Who Consumed (Attendance / Division) */}
        <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>{t('whoConsumed')}</span>
            </label>
            <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
              {usedBy.length} {t('selectedConsumersCount')}
            </span>
          </div>

          {/* Preset Buttons */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => applyPreset('all')}
              className="px-2.5 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-[11px] font-bold text-zinc-200 border border-zinc-700 transition"
            >
              👥 {t('presetAll')}
            </button>
            <button
              type="button"
              onClick={() => applyPreset('no_ashvin')}
              className="px-2.5 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-[11px] font-bold text-zinc-200 border border-zinc-700 transition"
            >
              ☕ {t('presetNoAshvinMorning')}
            </button>
            <button
              type="button"
              onClick={() => applyPreset('evening')}
              className="px-2.5 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-[11px] font-bold text-zinc-200 border border-zinc-700 transition"
            >
              🍶 {t('presetEveningChhaas')}
            </button>
          </div>

          {/* Member Consumer Chips */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
            {CANONICAL_MEMBERS.map((member) => {
              const isSelected = usedBy.includes(member.name);
              return (
                <button
                  type="button"
                  key={member.id}
                  onClick={() => toggleConsumer(member.name)}
                  className={`p-2.5 rounded-2xl border text-left transition flex items-center justify-between ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500/60 text-zinc-100 shadow-sm'
                      : 'bg-zinc-950/60 border-zinc-800 text-zinc-500 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black text-zinc-950"
                      style={{ backgroundColor: member.avatarColor }}
                    >
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-xs font-bold leading-tight">
                        {language === 'gu' ? member.nameGu : member.name}
                      </div>
                      <div className="text-[10px] text-zinc-400">
                        {member.id === 'rajesh' ? '~20 days' : member.id === 'ashvin' ? 'No AM tea' : 'Member'}
                      </div>
                    </div>
                  </div>

                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
                      isSelected ? 'bg-amber-500 text-zinc-950' : 'bg-zinc-800 text-zinc-600'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Live Share Calculation Banner */}
          <div className="p-3 rounded-2xl bg-zinc-950 border border-amber-500/30 flex items-center justify-between">
            <span className="text-xs text-zinc-400">
              {t('eachPersonShare')}:
            </span>
            <div className="text-right">
              <span className="text-sm md:text-base font-black text-amber-400">
                ₹{splitPerPerson}
              </span>
              <span className="text-[10px] text-zinc-400 ml-1">
                ({numAmount} ÷ {usedBy.length})
              </span>
            </div>
          </div>
        </div>

        {/* Paid By & Payment Type (Paid vs Udhar) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {/* Paid By */}
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-2">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider block">
              {t('paidBy')}
            </label>
            <select
              value={paidBy}
              onChange={(e) => setPaidBy(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-3.5 py-2.5 text-xs font-bold text-zinc-100 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              {CANONICAL_MEMBERS.map((m) => (
                <option key={m.id} value={m.name}>
                  {language === 'gu' ? m.nameGu : m.name} ({m.email})
                </option>
              ))}
            </select>
          </div>

          {/* Payment Type Toggle */}
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-2">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider block">
              {t('paymentTypeLabel')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPaymentType('paid')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition ${
                  paymentType === 'paid'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-sm'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {t('paid')}
              </button>
              <button
                type="button"
                onClick={() => setPaymentType('udhar')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition ${
                  paymentType === 'udhar'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {t('udhar')}
              </button>
            </div>
          </div>
        </div>

        {/* Date & Optional Notes */}
        <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'gu' ? 'તારીખ' : 'Date'}</span>
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs font-bold text-amber-300 focus:outline-none cursor-pointer"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1 block">
              {language === 'gu' ? 'નોંધ (વૈકલ્પિક)' : 'Notes (Optional)'}
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={t('notesPlaceholder')}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 active:scale-[0.98] transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <span>{t('saving')}</span>
          ) : (
            <>
              <PlusCircle className="w-5 h-5 stroke-[2.5]" />
              <span>{t('submitExpense')}</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
