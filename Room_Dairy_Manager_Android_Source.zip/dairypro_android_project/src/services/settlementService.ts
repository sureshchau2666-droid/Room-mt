/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { doc, getDoc, setDoc, collection, onSnapshot, query, where } from 'firebase/firestore';
import { db, auth } from '../firebase/config';
import { 
  ExpenseItem, 
  MemberMonthlyConsumption, 
  MonthlySettlementRecord, 
  SettlementStatus, 
  CANONICAL_MEMBERS,
  ADMIN_EMAIL 
} from '../types';
import { createNotification } from './notificationService';

export function calculateMonthlyConsumption(
  expenses: ExpenseItem[],
  settlementOverrides: Record<string, Partial<MonthlySettlementRecord>> = {}
): {
  membersBreakdown: MemberMonthlyConsumption[];
  totalMilkSpend: number;
  totalChhaasSpend: number;
  totalCurdSpend: number;
  grandTotalSpend: number;
  totalDueToDairy: number;
} {
  // Initialize map for the 5 canonical members
  const memberMap: Record<string, MemberMonthlyConsumption> = {};

  CANONICAL_MEMBERS.forEach((m) => {
    memberMap[m.name] = {
      memberId: m.id,
      memberName: m.name,
      memberNameGu: m.nameGu,
      milkAmount: 0,
      chhaasAmount: 0,
      curdAmount: 0,
      totalAmount: 0,
      paidAmount: 0,
      udharAmount: 0,
      dueAmount: 0,
      status: 'pending',
    };
  });

  let totalMilkSpend = 0;
  let totalChhaasSpend = 0;
  let totalCurdSpend = 0;
  let grandTotalSpend = 0;

  expenses.forEach((expense) => {
    const amt = Number(expense.amount) || 0;
    grandTotalSpend += amt;

    if (expense.category === 'milk') totalMilkSpend += amt;
    else if (expense.category === 'chhaas') totalChhaasSpend += amt;
    else if (expense.category === 'curd') totalCurdSpend += amt;

    const consumers = expense.usedBy && expense.usedBy.length > 0 ? expense.usedBy : [];
    if (consumers.length > 0) {
      const perPersonShare = amt / consumers.length;

      consumers.forEach((consumerName) => {
        const target = memberMap[consumerName];
        if (target) {
          if (expense.category === 'milk') {
            target.milkAmount += perPersonShare;
          } else if (expense.category === 'chhaas') {
            target.chhaasAmount += perPersonShare;
          } else if (expense.category === 'curd') {
            target.curdAmount += perPersonShare;
          }

          if (expense.paymentType === 'udhar') {
            target.udharAmount += perPersonShare;
          }
        }
      });
    }
  });

  // Finalize totals and apply Admin recorded settlement status/payments
  let totalDueToDairy = 0;

  const membersBreakdown: MemberMonthlyConsumption[] = Object.values(memberMap).map((m) => {
    const total = Number((m.milkAmount + m.chhaasAmount + m.curdAmount).toFixed(2));
    const override = settlementOverrides[m.memberId];

    let paid = override && typeof override.paidAmount === 'number' ? override.paidAmount : 0;
    let status: SettlementStatus = override?.status || 'pending';

    if (status === 'paid' && paid < total) {
      paid = total;
    }

    const due = Math.max(0, Number((total - paid).toFixed(2)));
    if (paid >= total && total > 0) {
      status = 'paid';
    } else if (paid > 0 && paid < total) {
      status = 'partially_paid';
    }

    totalDueToDairy += due;

    return {
      ...m,
      milkAmount: Number(m.milkAmount.toFixed(2)),
      chhaasAmount: Number(m.chhaasAmount.toFixed(2)),
      curdAmount: Number(m.curdAmount.toFixed(2)),
      totalAmount: total,
      paidAmount: paid,
      udharAmount: Number(m.udharAmount.toFixed(2)),
      dueAmount: due,
      status,
      settlementNotes: override?.notes,
      lastUpdated: override?.lastUpdated,
      updatedBy: override?.updatedBy,
    };
  });

  return {
    membersBreakdown,
    totalMilkSpend: Number(totalMilkSpend.toFixed(2)),
    totalChhaasSpend: Number(totalChhaasSpend.toFixed(2)),
    totalCurdSpend: Number(totalCurdSpend.toFixed(2)),
    grandTotalSpend: Number(grandTotalSpend.toFixed(2)),
    totalDueToDairy: Number(totalDueToDairy.toFixed(2)),
  };
}

export function subscribeToMonthlySettlementRecords(
  month: string, // YYYY-MM
  callback: (records: Record<string, MonthlySettlementRecord>) => void
): () => void {
  if (!db) {
    callback({});
    return () => {};
  }

  const q = query(collection(db, 'settlements'), where('month', '==', month));

  return onSnapshot(q, (snapshot) => {
    const recordMap: Record<string, MonthlySettlementRecord> = {};
    snapshot.docs.forEach((d) => {
      const data = d.data() as MonthlySettlementRecord;
      if (data.memberId) {
        recordMap[data.memberId] = {
          ...data,
          id: d.id,
        };
      }
    });
    callback(recordMap);
  });
}

export async function updateMemberSettlementRecord(
  month: string,
  memberId: string,
  memberName: string,
  data: {
    status: SettlementStatus;
    paidAmount: number;
    notes?: string;
  },
  adminName: string
): Promise<void> {
  if (!db) throw new Error('Firestore is not initialized.');

  // Strict Admin Authorization Check
  if (!auth?.currentUser?.email || auth.currentUser.email.toLowerCase() !== ADMIN_EMAIL) {
    throw new Error('Unauthorized: Only Suresh (Admin) can update settlement records.');
  }

  const docId = `${month}_${memberId}`;
  const record: Partial<MonthlySettlementRecord> = {
    month,
    memberId,
    memberName,
    status: data.status,
    paidAmount: Number(data.paidAmount) || 0,
    notes: data.notes ? data.notes.trim() : '',
    lastUpdated: Date.now(),
    updatedBy: adminName,
  };

  await setDoc(doc(db, 'settlements', docId), record, { merge: true });

  await createNotification({
    title: `Settlement Updated for ${memberName}`,
    titleGu: `${memberName} માટે માસિક હિસાબ અપડેટ થયો`,
    body: `Admin ${adminName} updated status to ${data.status.toUpperCase()} (Paid: ₹${data.paidAmount}).`,
    bodyGu: `એડમિન ${adminName} દ્વારા હિસાબની સ્થિતિ બદલવામાં આવી (ચૂકવેલ: ₹${data.paidAmount}).`,
    category: 'settlement_updated',
  });
}

export function generateWhatsAppSettlementMessage(
  monthFormatted: string,
  breakdown: MemberMonthlyConsumption[],
  totalDairySpend: number,
  language: 'en' | 'gu' = 'gu'
): string {
  if (language === 'gu') {
    let msg = `🥛 *રૂમ ડેરી હિસાબ – ${monthFormatted}*\n`;
    msg += `📍 *ડેરી માલિકને સીધી ચુકવણી (દરેક સભ્યએ પોતાનો હિસ્સો આપવો)*\n\n`;
    msg += `📊 *કુલ ડેરી ખર્ચ: ₹${totalDairySpend}*\n`;
    msg += `─────────────────────────\n`;

    breakdown.forEach((m, idx) => {
      const statusIcon = m.status === 'paid' ? '✅ ચૂકતે' : m.status === 'partially_paid' ? '⏳ આંશિક' : '❌ બાકી';
      msg += `*${idx + 1}. ${m.memberName}*\n`;
      msg += `  • દૂધ: ₹${m.milkAmount} | છાશ: ₹${m.chhaasAmount} | દહીં: ₹${m.curdAmount}\n`;
      msg += `  • કુલ વપરાશ: *₹${m.totalAmount}*\n`;
      msg += `  • સ્થિતિ: ${statusIcon} (બાકી: *₹${m.dueAmount}*)\n\n`;
    });

    msg += `─────────────────────────\n`;
    msg += `ℹ️ *નોંધ:* દરેક સભ્યએ પોતપોતાનો બાકી હિસ્સો ડેરી વાળાને રૂબરૂ ચૂકતે કરી દેવો.`;
    return encodeURIComponent(msg);
  } else {
    let msg = `🥛 *ROOM DAIRY SETTLEMENT – ${monthFormatted}*\n`;
    msg += `📍 *Direct Payment to Dairy Owner (No Common Pool)*\n\n`;
    msg += `📊 *Total Dairy Expenses: ₹${totalDairySpend}*\n`;
    msg += `─────────────────────────\n`;

    breakdown.forEach((m, idx) => {
      const statusLabel = m.status === 'paid' ? '✅ Paid' : m.status === 'partially_paid' ? '⏳ Partial' : '❌ Pending';
      msg += `*${idx + 1}. ${m.memberName}*\n`;
      msg += `  • Milk: ₹${m.milkAmount} | Chhaas: ₹${m.chhaasAmount} | Curd: ₹${m.curdAmount}\n`;
      msg += `  • Total Share: *₹${m.totalAmount}*\n`;
      msg += `  • Status: ${statusLabel} (Due: *₹${m.dueAmount}*)\n\n`;
    });

    msg += `─────────────────────────\n`;
    msg += `ℹ️ *Note:* Please clear your respective due balance directly with the dairy owner.`;
    return encodeURIComponent(msg);
  }
}
