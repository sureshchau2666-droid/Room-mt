# Room Dairy Manager – Android APK બનાવવાની રીત

આ ZIP માં હાલનો React + Firebase source code અને Capacitor Android wrapper configuration ઉમેરેલ છે. આ **હજુ compiled APK નથી**. APK બનાવવા માટે Android Studio/Android SDK ધરાવતા કમ્પ્યુટર પર નીચેના પગલાં જરૂરી છે.

## જરૂરી વસ્તુઓ
- Windows / macOS / Linux કમ્પ્યુટર
- Node.js 20 અથવા વધુ
- Android Studio અને Android SDK
- Java/JDK (Android Studio સાથે આવતું JDK વાપરી શકાય)

## પગલાં
1. ZIP extract કરો.
2. Project folder માં Terminal/Command Prompt ખોલો.
3. Dependencies ઇન્સ્ટોલ કરો:
   ```bash
   npm install
   ```
4. `.env.example` ની copy બનાવી `.env` નામ આપો. Firebase Console ના Web App config મુજબ values ભરો:
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `VITE_FIREBASE_APP_ID`
5. Android project પહેલી વાર બનાવો:
   ```bash
   npx cap add android
   ```
6. Web app build અને Android files sync કરો:
   ```bash
   npm run android:sync
   ```
7. Android Studio ખોલો:
   ```bash
   npx cap open android
   ```
8. Android Studio માં **Build > Build Bundle(s) / APK(s) > Build APK(s)** પસંદ કરો.
9. Debug APK સામાન્ય રીતે અહીં મળશે:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## મહત્વપૂર્ણ
- APK build અને Firebase login/Firestore permissionsનું વાસ્તવિક device testing કર્યા વગર આ app ને production-ready ન ગણશો.
- Firebase Console માં Authentication provider અને Firestore Rules યોગ્ય રીતે configure હોવા જોઈએ.
- Firebase Web API key client app માં રહે છે; તેને Google Cloud માં યોગ્ય API restrictions આપો. Firebase Security Rules જ ડેટાની સુરક્ષા enforce કરે છે.
- PIN-only login જો custom backend/secure server-side verification વગર અમલમાં હોય તો production માટે સલામત નથી.
- Push notifications માટે FCM setup, Android notification permission અને યોગ્ય Firebase configuration અલગથી જરૂરી હોઈ શકે છે.
- આ ZIP કોઈ APK binary સમાવે છે એવું માનશો નહીં; આ APK compile કરવા માટેનો Android-ready source project છે.
