/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  resolveFirebaseConfig, 
  saveCustomFirebaseConfig, 
  clearCustomFirebaseConfig, 
  isFirebaseConfigured,
  FirebaseClientConfig 
} from '../firebase/config';
import { requestNotificationPermission } from '../services/notificationService';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { 
  Settings, 
  Languages, 
  KeyRound, 
  Database, 
  Download, 
  Bell, 
  LogOut, 
  CheckCircle, 
  AlertCircle, 
  ExternalLink, 
  Smartphone, 
  ShieldCheck, 
  Wifi, 
  WifiOff 
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { t, language, setLanguage } = useLanguage();
  const { 
    currentUser, 
    currentMember, 
    isAdmin, 
    logout, 
    updateMemberPin, 
    hasPinConfigured,
    reloadFirebase 
  } = useAuth();
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const isOnline = useOnlineStatus();

  // PIN change state
  const [showPinModal, setShowPinModal] = useState<boolean>(false);
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [pinError, setPinError] = useState<string>('');
  const [pinSuccess, setPinSuccess] = useState<string>('');
  const [isSavingPin, setIsSavingPin] = useState<boolean>(false);

  // Firebase Config modal state
  const [showFirebaseModal, setShowFirebaseModal] = useState<boolean>(false);
  const [webApiKey, setWebApiKey] = useState<string>(() => resolveFirebaseConfig().apiKey || '');
  const [webAppId, setWebAppId] = useState<string>(() => resolveFirebaseConfig().appId || '');
  const [fbSaveNotice, setFbSaveNotice] = useState<string>('');

  // Notification state
  const [notifGranted, setNotifGranted] = useState<boolean>(() => {
    return typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted';
  });

  const handleUpdatePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    setPinSuccess('');

    if (!/^\d{4}$/.test(newPin)) {
      setPinError(t('pinInvalid'));
      return;
    }

    if (newPin !== confirmPin) {
      setPinError(t('pinMismatch'));
      return;
    }

    setIsSavingPin(true);
    try {
      await updateMemberPin(newPin);
      setPinSuccess(t('pinSetSuccess'));
      setNewPin('');
      setConfirmPin('');
      setTimeout(() => {
        setShowPinModal(false);
        setPinSuccess('');
      }, 1500);
    } catch (err: any) {
      setPinError(err.message || 'Failed to update PIN');
    } finally {
      setIsSavingPin(false);
    }
  };

  const handleSaveFirebaseConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!webApiKey || webApiKey.trim().length < 10) {
      setFbSaveNotice('Please enter a valid Firebase Web API key.');
      return;
    }

    const current = resolveFirebaseConfig();
    const updated: FirebaseClientConfig = {
      ...current,
      apiKey: webApiKey.trim(),
      appId: webAppId.trim(),
    };

    saveCustomFirebaseConfig(updated);
    reloadFirebase();
    setFbSaveNotice('Configuration saved! Firebase re-initialized.');
    setTimeout(() => {
      setShowFirebaseModal(false);
      setFbSaveNotice('');
    }, 1200);
  };

  const handleEnableNotifications = async () => {
    const granted = await requestNotificationPermission();
    setNotifGranted(granted);
  };

  return (
    <div className="max-w-xl mx-auto space-y-5 animate-fade-in pb-16">
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-black text-zinc-100 tracking-tight flex items-center gap-2">
          <Settings className="w-6 h-6 text-amber-400" />
          <span>{t('settingsTitle')}</span>
        </h2>
        <p className="text-xs text-zinc-400">
          {currentMember?.name} ({currentUser?.email})
        </p>
      </div>

      {/* Language Section */}
      <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
        <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
          <Languages className="w-4 h-4 text-amber-400" />
          <span>{t('language')}</span>
        </label>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => setLanguage('gu')}
            className={`p-3 rounded-2xl border text-center transition font-bold text-xs ${
              language === 'gu'
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <div className="text-sm font-black mb-0.5">ગુજરાતી</div>
            <div className="text-[10px] text-zinc-400">Gujarati (Default)</div>
          </button>

          <button
            type="button"
            onClick={() => setLanguage('en')}
            className={`p-3 rounded-2xl border text-center transition font-bold text-xs ${
              language === 'en'
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <div className="text-sm font-black mb-0.5">English</div>
            <div className="text-[10px] text-zinc-400">English (Global)</div>
          </button>
        </div>
      </div>

      {/* PIN Security Section */}
      <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-amber-400" />
            <span>{t('securityPin')}</span>
          </label>
          <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
            {hasPinConfigured ? 'SHA-256 Active' : 'Not Set'}
          </span>
        </div>

        <p className="text-xs text-zinc-400">
          {language === 'gu'
            ? '૪-અંકનો સુરક્ષિત PIN તમારા ઉપકરણ પર ઝડપી એક્સેસ માટે વપરાય છે. આ પાસવર્ડ કરતાં વધુ ઝડપી છે.'
            : 'A secure 4-digit PIN allows rapid authentication on your phone without retyping your password.'}
        </p>

        <button
          onClick={() => setShowPinModal(true)}
          className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-bold text-xs transition border border-zinc-700 flex items-center justify-center gap-2"
        >
          <KeyRound className="w-3.5 h-3.5" />
          <span>{hasPinConfigured ? t('changePin') : t('setupPin')}</span>
        </button>
      </div>

      {/* Firebase Project Information (room-fdba7) */}
      <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
            <Database className="w-4 h-4 text-amber-400" />
            <span>{t('firebaseProject')}</span>
          </label>
          <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
            room-fdba7
          </span>
        </div>

        <div className="space-y-1.5 text-xs text-zinc-300 bg-zinc-950/70 p-3 rounded-2xl border border-zinc-850">
          <div className="flex justify-between">
            <span className="text-zinc-500">{t('connectedProject')}:</span>
            <span className="font-mono font-bold text-amber-300">room-fdba7</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500">Project Number:</span>
            <span className="font-mono text-zinc-300">722320561512</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500">{t('firestoreRegion')}:</span>
            <span className="font-mono text-zinc-300">asia-south1 (Mumbai)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500">Database:</span>
            <span className="font-mono text-zinc-300">(default)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-500">{t('adminEmailNotice')}:</span>
            <span className="font-mono font-semibold text-amber-300">sureshchau2666@gmail.com</span>
          </div>
        </div>

        <button
          onClick={() => setShowFirebaseModal(true)}
          className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-xs transition border border-zinc-700 flex items-center justify-center gap-2"
        >
          <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
          <span>
            {language === 'gu'
              ? 'ફાયરબેઝ Web App API Key / કનેક્શન તપાસો'
              : 'Configure / Verify Web App Credentials'}
          </span>
        </button>
      </div>

      {/* PWA App Installation & Offline Status */}
      <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-amber-400" />
            <span>{t('pwaInstall')}</span>
          </label>
          <span className="text-[11px] font-semibold text-zinc-400 flex items-center gap-1">
            {isOnline ? (
              <>
                <Wifi className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-amber-400" />
                <span className="text-amber-400">Offline</span>
              </>
            )}
          </span>
        </div>

        {isInstalled ? (
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{t('installedOnDevice')}</span>
          </div>
        ) : (
          <button
            onClick={install}
            disabled={!isInstallable}
            className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t('installNow')}</span>
          </button>
        )}

        {/* Download Project Source ZIP */}
        <a
          href="/room-dairy-manager.zip"
          download="room-dairy-manager.zip"
          className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-bold text-xs transition border border-zinc-700 flex items-center justify-center gap-2"
        >
          <Download className="w-3.5 h-3.5 text-amber-400" />
          <span>
            {language === 'gu'
              ? 'પ્રોજેક્ટ સોર્સ કોડ ZIP ડાઉનલોડ કરો (.zip)'
              : 'Download Source Code Archive (.zip)'}
          </span>
        </a>
      </div>

      {/* Notifications Toggle */}
      <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
        <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-2">
          <Bell className="w-4 h-4 text-amber-400" />
          <span>{t('notifications')}</span>
        </label>
        <div className="flex items-center justify-between">
          <span className="text-xs text-zinc-400">
            {notifGranted
              ? t('notificationsActive')
              : (language === 'gu' ? 'નવા ખર્ચની તાત્કાલિક સૂચનાઓ મેળવો' : 'Get notified when expenses are added')}
          </span>
          <button
            onClick={handleEnableNotifications}
            disabled={notifGranted}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              notifGranted
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500 hover:bg-amber-400 text-zinc-950'
            }`}
          >
            {notifGranted ? 'Active' : t('enableNotifications')}
          </button>
        </div>
      </div>

      {/* Logout Button */}
      <button
        onClick={logout}
        className="w-full py-3.5 rounded-2xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 font-bold text-xs transition flex items-center justify-center gap-2"
      >
        <LogOut className="w-4 h-4" />
        <span>{t('logout')}</span>
      </button>

      {/* PIN Change Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-zinc-900 border border-amber-500/40 p-5 shadow-2xl space-y-4">
            <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span>{hasPinConfigured ? t('changePin') : t('setupPin')}</span>
            </h3>

            {pinSuccess && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>{pinSuccess}</span>
              </div>
            )}

            {pinError && (
              <div className="p-2.5 rounded-xl bg-red-500/20 text-red-300 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <span>{pinError}</span>
              </div>
            )}

            <form onSubmit={handleUpdatePin} className="space-y-3">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t('enterNewPin')}</label>
                <input
                  type="password"
                  maxLength={4}
                  pattern="\d{4}"
                  inputMode="numeric"
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-center text-xl font-bold tracking-widest text-amber-300 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-zinc-400 mb-1">{t('confirmNewPin')}</label>
                <input
                  type="password"
                  maxLength={4}
                  pattern="\d{4}"
                  inputMode="numeric"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-center text-xl font-bold tracking-widest text-amber-300 focus:outline-none"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPinModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingPin}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400 disabled:opacity-50"
                >
                  {isSavingPin ? 'Saving...' : 'Save PIN'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Firebase Credentials Modal */}
      {showFirebaseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-zinc-900 border border-amber-500/40 p-5 shadow-2xl space-y-4">
            <h3 className="font-bold text-sm text-zinc-100 flex items-center gap-2">
              <Database className="w-4 h-4 text-amber-400" />
              <span>Firebase Web Credentials (room-fdba7)</span>
            </h3>

            <p className="text-xs text-zinc-400 leading-relaxed">
              Target Project: <strong className="text-amber-400">room-fdba7</strong>. You can find your Web API key in Firebase Console → Project Overview ⚙️ → Project Settings → General → "Your apps".
            </p>

            {fbSaveNotice && (
              <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 text-xs font-bold">
                {fbSaveNotice}
              </div>
            )}

            <form onSubmit={handleSaveFirebaseConfig} className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-semibold mb-1">
                  Web API Key (apiKey):
                </label>
                <input
                  type="text"
                  value={webApiKey}
                  onChange={(e) => setWebApiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-200 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">
                  App ID (optional):
                </label>
                <input
                  type="text"
                  value={webAppId}
                  onChange={(e) => setWebAppId(e.target.value)}
                  placeholder="1:722320561512:web:..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-200 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowFirebaseModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400"
                >
                  Save & Connect
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
