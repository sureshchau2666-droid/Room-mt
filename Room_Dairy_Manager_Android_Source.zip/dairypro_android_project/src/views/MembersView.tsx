/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { CANONICAL_MEMBERS, ExpenseItem } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  Users, 
  ShieldCheck, 
  User, 
  Coffee, 
  Milk, 
  Calendar, 
  Info, 
  CheckCircle 
} from 'lucide-react';

interface MembersViewProps {
  expenses: ExpenseItem[];
  currentMonth: string;
}

export const MembersView: React.FC<MembersViewProps> = ({
  expenses,
  currentMonth,
}) => {
  const { t, language } = useLanguage();
  const { currentMember, isAdmin } = useAuth();

  const monthlyExpenses = useMemo(() => {
    return expenses.filter((e) => e.date.startsWith(currentMonth));
  }, [expenses, currentMonth]);

  // Consumption share per member
  const memberSpendMap = useMemo(() => {
    const map: Record<string, { total: number; milk: number; chhaas: number; curd: number; entriesCount: number }> = {};
    CANONICAL_MEMBERS.forEach((m) => {
      map[m.name] = { total: 0, milk: 0, chhaas: 0, curd: 0, entriesCount: 0 };
    });

    monthlyExpenses.forEach((e) => {
      if (e.usedBy && e.usedBy.length > 0) {
        const split = Number(e.amount) / e.usedBy.length;
        e.usedBy.forEach((cName) => {
          if (map[cName]) {
            map[cName].total += split;
            map[cName].entriesCount += 1;
            if (e.category === 'milk') map[cName].milk += split;
            else if (e.category === 'chhaas') map[cName].chhaas += split;
            else if (e.category === 'curd') map[cName].curd += split;
          }
        });
      }
    });

    return map;
  }, [monthlyExpenses]);

  const memberHabits: Record<string, { habitEn: string; habitGu: string; icon: string }> = {
    suresh: {
      habitEn: 'Room Dairy Manager & Sole Administrator. Manages records and dairy settlements.',
      habitGu: 'રૂમ ડેરી સંચાલક અને એકમાત્ર એડમિન. ડેરી હિસાબ અને સેટલમેન્ટનું સંચાલન કરે છે.',
      icon: '👑',
    },
    ashvin: {
      habitEn: 'Does not drink morning tea/milk. Included in evening chhaas and cooking curd.',
      habitGu: 'સવારની ચા કે દૂધ પીતા નથી. સાંજની છાશ અને રસોઈના દહીંમાં ભાગીદાર.',
      icon: '🍵',
    },
    ramesh: {
      habitEn: 'Regular room resident. Full-time consumer of morning milk and daily chhaas.',
      habitGu: 'રૂમના નિયમિત સભ્ય. સવારના દૂધ અને દૈનિક છાશમાં નિયમિત વપરાશ.',
      icon: '🥛',
    },
    prakash: {
      habitEn: 'Regular room resident. Full-time consumer of morning milk and daily chhaas.',
      habitGu: 'રૂમના નિયમિત સભ્ય. સવારના દૂધ અને દૈનિક છાશમાં નિયમિત વપરાશ.',
      icon: '🥛',
    },
    rajesh: {
      habitEn: 'Stays ~20 days per month in room. Consumes dairy strictly when residing.',
      habitGu: 'મહિનામાં અંદાજે ૨૦ દિવસ રૂમ પર રહે છે. હાજર હોય તે દિવસોમાં જ ભાગ ગણાય છે.',
      icon: '🗓️',
    },
  };

  return (
    <div className="space-y-5 animate-fade-in pb-16">
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-black text-zinc-100 tracking-tight flex items-center gap-2">
          <Users className="w-6 h-6 text-amber-400" />
          <span>{t('membersTitle')}</span>
        </h2>
        <p className="text-xs text-zinc-400">
          {language === 'gu'
            ? '૫ અધિકૃત સભ્યો • સુરેશભાઈ (એડમિન) અને ૪ સભ્યો'
            : '5 Authorized Room Members • Suresh (Admin) & 4 Members'}
        </p>
      </div>

      {/* Permissions Transparency Notice */}
      <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-3.5 text-xs text-zinc-300 space-y-1">
        <div className="flex items-center gap-2 text-amber-400 font-bold">
          <ShieldCheck className="w-4 h-4" />
          <span>
            {language === 'gu' ? 'પરમિશન માળખું (સુરક્ષા)' : 'Role & Security Permissions'}
          </span>
        </div>
        <p className="text-zinc-400 text-[11px] leading-relaxed">
          {language === 'gu'
            ? '• સુરેશ (sureshchau2666@gmail.com) એકમાત્ર એડમિન છે અને એન્ટ્રીઓ સુધારી/હટાવી તેમજ માસિક સ્થિતિ અપડેટ કરી શકે છે.\n• અન્ય ૪ સભ્યો ખર્ચ ઉમેરી શકે છે અને પોતાનો હિસ્સો જોઈ શકે છે.'
            : '• Suresh (sureshchau2666@gmail.com) is the sole administrator authorized to edit/delete entries and update settlement status.\n• All members can add new expenses and view their individual consumption.'}
        </p>
      </div>

      {/* Member Cards */}
      <div className="space-y-3">
        {CANONICAL_MEMBERS.map((member) => {
          const habit = memberHabits[member.id];
          const stats = memberSpendMap[member.name] || { total: 0, milk: 0, chhaas: 0, curd: 0, entriesCount: 0 };
          const isMe = currentMember?.name === member.name;

          return (
            <div
              key={member.id}
              className={`p-4 md:p-5 rounded-3xl border transition space-y-3 ${
                isMe
                  ? 'bg-gradient-to-br from-zinc-900 via-zinc-900 to-amber-500/10 border-amber-500/50 shadow-md ring-1 ring-amber-500/20'
                  : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-base font-black text-zinc-950 shadow-md shrink-0"
                    style={{ backgroundColor: member.avatarColor }}
                  >
                    {member.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-base font-extrabold text-zinc-100">
                        {language === 'gu' ? member.nameGu : member.name}
                      </h4>
                      {isMe && (
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-500 text-zinc-950">
                          {language === 'gu' ? 'તમે' : 'You'}
                        </span>
                      )}
                      {member.role === 'admin' ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40">
                          Admin
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 border border-zinc-700">
                          Member
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      {member.email}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] font-semibold text-zinc-400 block uppercase tracking-wider">
                    {language === 'gu' ? 'આ મહિનાનો વપરાશ' : 'This Month'}
                  </span>
                  <div className="text-base md:text-lg font-black text-amber-400">
                    ₹{stats.total.toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Attendance & Consumption Habit */}
              <div className="p-3 rounded-2xl bg-zinc-950/70 border border-zinc-850 flex items-start gap-2.5 text-xs text-zinc-300">
                <span className="text-lg shrink-0 mt-0.5">{habit.icon}</span>
                <div>
                  <span className="font-bold text-amber-300 block mb-0.5">
                    {language === 'gu' ? 'વપરાશ પેટર્ન અને હાજરી' : 'Consumption Pattern & Attendance'}
                  </span>
                  <p className="text-[11px] text-zinc-400 leading-relaxed">
                    {language === 'gu' ? habit.habitGu : habit.habitEn}
                  </p>
                </div>
              </div>

              {/* Monthly breakdown stats */}
              <div className="grid grid-cols-3 gap-2 pt-1 border-t border-zinc-800/60 text-center text-xs">
                <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800/80">
                  <span className="text-[10px] text-zinc-400 block">🥛 {t('milk')}</span>
                  <span className="font-bold text-zinc-200">₹{stats.milk.toFixed(1)}</span>
                </div>
                <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800/80">
                  <span className="text-[10px] text-zinc-400 block">🍶 {t('chhaas')}</span>
                  <span className="font-bold text-zinc-200">₹{stats.chhaas.toFixed(1)}</span>
                </div>
                <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800/80">
                  <span className="text-[10px] text-zinc-400 block">🥣 {t('curd')}</span>
                  <span className="font-bold text-zinc-200">₹{stats.curd.toFixed(1)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
