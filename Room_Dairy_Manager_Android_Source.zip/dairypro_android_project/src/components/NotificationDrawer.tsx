/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppNotification } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { markNotificationAsRead } from '../services/notificationService';
import { X, Bell, Check, Clock, Milk, Trash2, Edit3, DollarSign } from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
}) => {
  const { language } = useLanguage();
  const { currentMember, currentUser } = useAuth();

  if (!isOpen) return null;

  const userIdentifier = currentMember?.name || currentUser?.email || 'user';

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'expense_added':
        return <Milk className="w-4 h-4 text-amber-400" />;
      case 'expense_deleted':
        return <Trash2 className="w-4 h-4 text-red-400" />;
      case 'settlement_updated':
        return <DollarSign className="w-4 h-4 text-emerald-400" />;
      default:
        return <Bell className="w-4 h-4 text-amber-400" />;
    }
  };

  const formatTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const mins = Math.floor(diff / (60 * 1000));
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);

    if (mins < 1) return language === 'gu' ? 'હમણાં જ' : 'Just now';
    if (mins < 60) return `${mins} ${language === 'gu' ? 'મિનિટ પહેલાં' : 'mins ago'}`;
    if (hours < 24) return `${hours} ${language === 'gu' ? 'કલાક પહેલાં' : 'hrs ago'}`;
    return `${days} ${language === 'gu' ? 'દિવસ પહેલાં' : 'days ago'}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-sm h-full bg-zinc-900 border-l border-amber-500/20 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-zinc-100">
                {language === 'gu' ? 'સૂચનાઓ' : 'Notifications'}
              </h3>
              <p className="text-xs text-zinc-400">
                {notifications.length} {language === 'gu' ? 'કુલ સૂચનાઓ' : 'total notifications'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {notifications.length === 0 ? (
            <div className="py-16 text-center text-zinc-500">
              <Bell className="w-10 h-10 mx-auto mb-2 opacity-30 text-amber-400" />
              <p className="text-sm">
                {language === 'gu' ? 'કોઈ નવી સૂચના નથી' : 'No notifications yet'}
              </p>
            </div>
          ) : (
            notifications.map((item) => {
              const isRead = item.readBy.includes(userIdentifier);
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    if (!isRead) {
                      markNotificationAsRead(item.id, userIdentifier);
                    }
                  }}
                  className={`p-3 rounded-2xl border transition cursor-pointer ${
                    isRead
                      ? 'bg-zinc-900/60 border-zinc-800/80 text-zinc-300'
                      : 'bg-zinc-850 border-amber-500/40 text-zinc-100 shadow-md ring-1 ring-amber-500/20'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className="mt-0.5 p-1.5 rounded-lg bg-zinc-800 shrink-0">
                      {getCategoryIcon(item.category)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-xs font-bold text-amber-300 truncate">
                          {language === 'gu' ? item.titleGu : item.title}
                        </h4>
                        {!isRead && (
                          <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                        )}
                      </div>
                      <p className="text-xs text-zinc-300 mt-1 leading-snug">
                        {language === 'gu' ? item.bodyGu : item.body}
                      </p>
                      <div className="flex items-center gap-1 text-[10px] text-zinc-500 mt-2">
                        <Clock className="w-3 h-3" />
                        <span>{formatTime(item.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
