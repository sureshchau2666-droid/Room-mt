/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { ExpenseItem, DairyCategory, PaymentType, CANONICAL_MEMBERS } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { updateExpense, deleteExpense } from '../services/expenseService';
import { 
  Receipt, 
  Search, 
  Filter, 
  Trash2, 
  Edit3, 
  Calendar, 
  Check, 
  X, 
  ShieldAlert, 
  Users, 
  AlertCircle 
} from 'lucide-react';

interface ExpensesViewProps {
  expenses: ExpenseItem[];
  currentMonth: string;
  setCurrentMonth: (m: string) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses,
  currentMonth,
  setCurrentMonth,
}) => {
  const { t, language } = useLanguage();
  const { currentMember, isAdmin } = useAuth();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [consumerFilter, setConsumerFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Editing state
  const [editingExpense, setEditingExpense] = useState<ExpenseItem | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [editCategory, setEditCategory] = useState<DairyCategory>('milk');
  const [editPaymentType, setEditPaymentType] = useState<PaymentType>('paid');
  const [editUsedBy, setEditUsedBy] = useState<string[]>([]);
  const [editNotes, setEditNotes] = useState<string>('');
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  // Deleting confirmation state
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Filtered expenses
  const filteredExpenses = useMemo(() => {
    return expenses.filter((e) => {
      // Month
      if (!e.date.startsWith(currentMonth)) return false;

      // Category
      if (categoryFilter !== 'all' && e.category !== categoryFilter) return false;

      // Payment Type
      if (paymentFilter !== 'all' && e.paymentType !== paymentFilter) return false;

      // Consumer
      if (consumerFilter !== 'all' && (!e.usedBy || !e.usedBy.includes(consumerFilter))) return false;

      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const inNotes = e.notes?.toLowerCase().includes(query);
        const inCreator = e.createdByName?.toLowerCase().includes(query);
        const inPaidBy = e.paidBy?.toLowerCase().includes(query);
        if (!inNotes && !inCreator && !inPaidBy) return false;
      }

      return true;
    });
  }, [expenses, currentMonth, categoryFilter, paymentFilter, consumerFilter, searchQuery]);

  const totalFilteredSum = useMemo(() => {
    return filteredExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [filteredExpenses]);

  // Open Edit Modal
  const openEditModal = (expense: ExpenseItem) => {
    setEditingExpense(expense);
    setEditAmount(String(expense.amount));
    setEditCategory(expense.category);
    setEditPaymentType(expense.paymentType);
    setEditUsedBy(expense.usedBy);
    setEditNotes(expense.notes || '');
  };

  const handleSaveEdit = async () => {
    if (!isAdmin || !editingExpense) return;
    const num = Number(editAmount);
    if (!num || num <= 0 || editUsedBy.length === 0) return;

    setIsUpdating(true);
    try {
      await updateExpense(
        editingExpense.id,
        {
          amount: num,
          category: editCategory,
          paymentType: editPaymentType,
          usedBy: editUsedBy,
          notes: editNotes,
        },
        currentMember?.name || 'Suresh'
      );
      setEditingExpense(null);
    } catch (err) {
      console.error(err);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!isAdmin) return;
    setIsDeleting(true);
    try {
      await deleteExpense(id, currentMember?.name || 'Suresh');
      setDeletingId(null);
    } catch (err) {
      console.error(err);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-4 animate-fade-in pb-16">
      {/* Title & Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-zinc-100 tracking-tight">
            {t('expenses')}
          </h2>
          <p className="text-xs text-zinc-400">
            {filteredExpenses.length} {language === 'gu' ? 'એન્ટ્રીઓ' : 'entries'} •{' '}
            {language === 'gu' ? 'કુલ સરવાળો:' : 'Total:'} <span className="text-amber-400 font-extrabold">₹{totalFilteredSum.toFixed(2)}</span>
          </p>
        </div>

        {/* Month Selector */}
        <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-200">
          <Calendar className="w-3.5 h-3.5 text-amber-400" />
          <input
            type="month"
            value={currentMonth}
            onChange={(e) => setCurrentMonth(e.target.value)}
            className="bg-transparent text-xs text-amber-300 font-bold focus:outline-none cursor-pointer"
          />
        </div>
      </div>

      {/* Filter Bar */}
      <div className="rounded-3xl bg-zinc-900/80 border border-zinc-800 p-3 space-y-2.5">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('searchNotes')}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2 text-xs text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="grid grid-cols-3 gap-2">
          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-2.5 py-1.5 text-xs text-zinc-300 focus:outline-none"
          >
            <option value="all">{t('allCategories')}</option>
            <option value="milk">🥛 {t('milk')}</option>
            <option value="chhaas">🍶 {t('chhaas')}</option>
            <option value="curd">🥣 {t('curd')}</option>
          </select>

          {/* Payment Filter */}
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-2.5 py-1.5 text-xs text-zinc-300 focus:outline-none"
          >
            <option value="all">{t('allPaymentTypes')}</option>
            <option value="paid">✅ {t('paid')}</option>
            <option value="udhar">📝 {t('udhar')}</option>
          </select>

          {/* Consumer Filter */}
          <select
            value={consumerFilter}
            onChange={(e) => setConsumerFilter(e.target.value)}
            className="bg-zinc-950 border border-zinc-800 rounded-xl px-2.5 py-1.5 text-xs text-zinc-300 focus:outline-none"
          >
            <option value="all">{language === 'gu' ? 'બધા સભ્યો' : 'All Members'}</option>
            {CANONICAL_MEMBERS.map((m) => (
              <option key={m.id} value={m.name}>
                {m.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Expenses Cards List */}
      <div className="space-y-2.5">
        {filteredExpenses.length === 0 ? (
          <div className="py-16 text-center text-zinc-500 rounded-3xl bg-zinc-900/40 border border-zinc-800/60 p-6">
            <Receipt className="w-12 h-12 mx-auto mb-2 opacity-30 text-amber-400" />
            <p className="text-xs">{t('emptyExpensesList')}</p>
          </div>
        ) : (
          filteredExpenses.map((expense) => {
            const emoji =
              expense.category === 'milk' ? '🥛' : expense.category === 'chhaas' ? '🍶' : '🥣';
            const split = (expense.amount / (expense.usedBy.length || 1)).toFixed(2);

            return (
              <div
                key={expense.id}
                className="p-4 rounded-3xl bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 transition space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-zinc-800 flex items-center justify-center text-xl shrink-0">
                      {emoji}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-zinc-100">
                          {t(expense.category)}
                        </h4>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            expense.paymentType === 'paid'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {expense.paymentType === 'paid' ? t('paid') : t('udhar')}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        {expense.date} • {language === 'gu' ? 'ચૂકવનાર:' : 'Paid by:'} {expense.paidBy}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-base md:text-lg font-black text-amber-400">
                      ₹{expense.amount}
                    </div>
                    <div className="text-[11px] font-semibold text-zinc-400">
                      ₹{split} / {language === 'gu' ? 'માથાદીઠ' : 'person'}
                    </div>
                  </div>
                </div>

                {/* Consumer Chips */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-zinc-800/60">
                  <span className="text-[11px] text-zinc-400 mr-1 flex items-center gap-1">
                    <Users className="w-3 h-3 text-amber-400" />
                    <span>{language === 'gu' ? 'વાપરનાર:' : 'Consumers:'}</span>
                  </span>
                  {expense.usedBy.map((cName) => (
                    <span
                      key={cName}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded-lg bg-zinc-800 text-zinc-300 border border-zinc-700"
                    >
                      {cName}
                    </span>
                  ))}
                </div>

                {/* Notes if any */}
                {expense.notes && (
                  <p className="text-[11px] text-zinc-400 italic bg-zinc-950/60 p-2 rounded-xl border border-zinc-850">
                    "{expense.notes}"
                  </p>
                )}

                {/* Bottom Actions: Admin Edit/Delete or Member Read-Only Notice */}
                <div className="flex items-center justify-between pt-1 text-[11px] text-zinc-400">
                  <span>
                    {language === 'gu' ? 'નોંધણી:' : 'Recorded by:'} {expense.createdByName}
                  </span>

                  {isAdmin ? (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEditModal(expense)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-300 text-xs font-semibold transition"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>{t('editEntry')}</span>
                      </button>
                      <button
                        onClick={() => setDeletingId(expense.id)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-semibold transition"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>{t('deleteEntry')}</span>
                      </button>
                    </div>
                  ) : (
                    <span className="text-[10px] text-zinc-400 italic">
                      {language === 'gu' ? 'સુરેશ (એડમિન) અધિકૃત' : 'Admin protected'}
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Admin Edit Modal */}
      {editingExpense && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-zinc-900 border border-amber-500/40 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm md:text-base text-zinc-100 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>{t('editEntry')}</span>
              </h3>
              <button
                onClick={() => setEditingExpense(null)}
                className="p-1 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-semibold mb-1">{t('amount')}</label>
                <input
                  type="number"
                  value={editAmount}
                  onChange={(e) => setEditAmount(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-base font-bold text-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">{t('selectCategory')}</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['milk', 'chhaas', 'curd'] as DairyCategory[]).map((cat) => (
                    <button
                      type="button"
                      key={cat}
                      onClick={() => setEditCategory(cat)}
                      className={`p-2 rounded-xl border text-center font-bold ${
                        editCategory === cat
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      {t(cat)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">{t('paymentTypeLabel')}</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditPaymentType('paid')}
                    className={`p-2 rounded-xl border font-bold ${
                      editPaymentType === 'paid'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {t('paid')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditPaymentType('udhar')}
                    className={`p-2 rounded-xl border font-bold ${
                      editPaymentType === 'udhar'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {t('udhar')}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">{t('whoConsumed')}</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {CANONICAL_MEMBERS.map((m) => {
                    const sel = editUsedBy.includes(m.name);
                    return (
                      <button
                        type="button"
                        key={m.id}
                        onClick={() => {
                          if (sel) {
                            if (editUsedBy.length > 1) {
                              setEditUsedBy(editUsedBy.filter((n) => n !== m.name));
                            }
                          } else {
                            setEditUsedBy([...editUsedBy, m.name]);
                          }
                        }}
                        className={`p-1.5 rounded-xl border text-center font-bold text-[11px] ${
                          sel
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-500'
                        }`}
                      >
                        {m.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">
                  {language === 'gu' ? 'નોંધ' : 'Notes'}
                </label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setEditingExpense(null)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs hover:bg-zinc-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                disabled={isUpdating}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400 disabled:opacity-50"
              >
                {isUpdating ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Delete Confirmation Modal */}
      {deletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-zinc-900 border border-red-500/40 p-5 shadow-2xl text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-400 mx-auto flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-zinc-100 text-sm">
              {t('deleteConfirm')}
            </h3>
            <p className="text-xs text-zinc-400">
              {language === 'gu'
                ? 'આ એન્ટ્રી કાયમ માટે હટી જશે અને માસિક હિસાબમાંથી આપોઆપ બાદ થશે.'
                : 'This entry will be permanently removed and recalculated.'}
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setDeletingId(null)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs hover:bg-zinc-700"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deletingId)}
                disabled={isDeleting}
                className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold text-xs disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Delete Entry'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
