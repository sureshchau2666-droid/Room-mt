/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  LayoutDashboard, 
  Receipt, 
  PlusCircle, 
  Calculator, 
  Users, 
  Settings, 
  Bell, 
  Languages, 
  Lock, 
  ShieldCheck 
} from 'lucide-react';

export type ActiveTab = 'dashboard' | 'expenses' | 'add' | 'settlement' | 'members' | 'settings';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  unreadCount: number;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  unreadCount,
  onOpenNotifications,
}) => {
  const { language, setLanguage, t } = useLanguage();
  const { currentMember, isAdmin, lockSession, hasPinConfigured } = useAuth();

  const toggleLanguage = () => {
    setLanguage(language === 'gu' ? 'en' : 'gu');
  };

  const navItems = [
    { id: 'dashboard' as ActiveTab, label: t('dashboard'), icon: LayoutDashboard },
    { id: 'expenses' as ActiveTab, label: t('expenses'), icon: Receipt },
    { id: 'add' as ActiveTab, label: t('addEntry'), icon: PlusCircle, isHighlight: true },
    { id: 'settlement' as ActiveTab, label: t('settlement'), icon: Calculator },
    { id: 'members' as ActiveTab, label: t('members'), icon: Users },
    { id: 'settings' as ActiveTab, label: t('settings'), icon: Settings },
  ];

  return (
    <>
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800/80 px-4 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          {/* Logo & Brand */}
          <div 
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 shadow-md shadow-amber-500/20 group-hover:scale-105 transition">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <span className="text-xl">🥛</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base md:text-lg text-amber-400 tracking-tight leading-none">
                  {language === 'gu' ? 'રૂમ ડેરી મેનેજર' : 'Room Dairy Manager'}
                </h1>
                {isAdmin && (
                  <span className="flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40">
                    <ShieldCheck className="w-3 h-3" />
                    Admin
                  </span>
                )}
              </div>
              <p className="text-[11px] text-zinc-400 font-medium">
                {currentMember ? (
                  <span>
                    {language === 'gu' ? currentMember.nameGu : currentMember.name} • ૫ સભ્યોનો હિસાબ
                  </span>
                ) : (
                  '5 Members Shared Diary'
                )}
              </p>
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-1.5 md:gap-2.5">
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-zinc-800 bg-zinc-900/80 hover:bg-zinc-800 text-xs font-bold text-amber-300 transition active:scale-95"
              title="Change Language"
            >
              <Languages className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'gu' ? 'EN' : 'ગુજરાતી'}</span>
            </button>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-xl border border-zinc-800 bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 hover:text-amber-400 transition active:scale-95"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-amber-500 text-[10px] font-extrabold text-zinc-950 animate-pulse">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>

            {/* Quick PIN Lock (if PIN configured) */}
            {hasPinConfigured && (
              <button
                onClick={lockSession}
                className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-zinc-800 bg-zinc-900/80 hover:bg-zinc-800 text-xs font-medium text-zinc-400 hover:text-white transition active:scale-95"
                title="Lock Session with PIN"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{language === 'gu' ? 'લૉક' : 'Lock'}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Desktop Navigation Bar */}
      <nav className="hidden md:block bg-zinc-900/60 border-b border-zinc-800/80 sticky top-[61px] z-30 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto flex items-center justify-between px-4 py-1.5">
          <div className="flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                    isActive
                      ? 'bg-amber-500 text-zinc-950 shadow-md shadow-amber-500/20'
                      : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-zinc-950' : 'text-amber-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="text-[11px] font-semibold text-zinc-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping" />
            <span>Firebase room-fdba7 Connected</span>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="no-print md:hidden fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800/90 pb-safe pt-1 px-2">
        <div className="flex items-center justify-around py-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            if (item.isHighlight) {
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className="flex flex-col items-center justify-center -mt-5 group"
                >
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-transform active:scale-90 ${
                      isActive
                        ? 'bg-amber-400 text-zinc-950 ring-4 ring-amber-500/30'
                        : 'bg-amber-500 text-zinc-950 hover:bg-amber-400'
                    }`}
                  >
                    <Icon className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <span className="text-[10px] font-bold text-amber-400 mt-1">
                    {item.label}
                  </span>
                </button>
              );
            }

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
                  isActive ? 'text-amber-400 font-bold' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'text-amber-400 stroke-[2.5]' : 'stroke-[1.8]'}`} />
                <span className="text-[10px] tracking-tight">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
