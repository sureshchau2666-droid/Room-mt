/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  ExpenseItem, 
  MemberMonthlyConsumption, 
  MonthlySettlementRecord, 
  SettlementStatus, 
  CANONICAL_MEMBERS 
} from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { 
  calculateMonthlyConsumption, 
  subscribeToMonthlySettlementRecords, 
  updateMemberSettlementRecord,
  generateWhatsAppSettlementMessage 
} from '../services/settlementService';
import { 
  Calculator, 
  Share2, 
  Printer, 
  Calendar, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  DollarSign, 
  Edit3, 
  X, 
  ShieldCheck, 
  Milk 
} from 'lucide-react';

interface SettlementViewProps {
  expenses: ExpenseItem[];
  currentMonth: string;
  setCurrentMonth: (m: string) => void;
}

export const SettlementView: React.FC<SettlementViewProps> = ({
  expenses,
  currentMonth,
  setCurrentMonth,
}) => {
  const { t, language } = useLanguage();
  const { currentMember, isAdmin } = useAuth();

  const [settlementOverrides, setSettlementOverrides] = useState<Record<string, MonthlySettlementRecord>>({});
  
  // Status update modal state
  const [selectedMember, setSelectedMember] = useState<MemberMonthlyConsumption | null>(null);
  const [editStatus, setEditStatus] = useState<SettlementStatus>('pending');
  const [editPaidAmount, setEditPaidAmount] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Subscribe to real-time settlement records in Firestore
  useEffect(() => {
    const unsub = subscribeToMonthlySettlementRecords(currentMonth, (records) => {
      setSettlementOverrides(records);
    });
    return () => unsub();
  }, [currentMonth]);

  const monthlyExpenses = useMemo(() => {
    return expenses.filter((e) => e.date.startsWith(currentMonth));
  }, [expenses, currentMonth]);

  const {
    membersBreakdown,
    totalMilkSpend,
    totalChhaasSpend,
    totalCurdSpend,
    grandTotalSpend,
    totalDueToDairy,
  } = useMemo(() => {
    return calculateMonthlyConsumption(monthlyExpenses, settlementOverrides);
  }, [monthlyExpenses, settlementOverrides]);

  const formatMonthName = (monthStr: string) => {
    const [y, m] = monthStr.split('-');
    const date = new Date(Number(y), Number(m) - 1, 1);
    return date.toLocaleDateString(language === 'gu' ? 'gu-IN' : 'en-US', {
      month: 'long',
      year: 'numeric',
    });
  };

  const handleOpenStatusModal = (member: MemberMonthlyConsumption) => {
    setSelectedMember(member);
    setEditStatus(member.status);
    setEditPaidAmount(String(member.paidAmount || ''));
    setEditNotes(member.settlementNotes || '');
  };

  const handleSaveStatus = async () => {
    if (!isAdmin || !selectedMember) return;
    setIsSaving(true);
    try {
      await updateMemberSettlementRecord(
        currentMonth,
        selectedMember.memberId,
        selectedMember.memberName,
        {
          status: editStatus,
          paidAmount: Number(editPaidAmount) || 0,
          notes: editNotes,
        },
        currentMember?.name || 'Suresh'
      );
      setSelectedMember(null);
    } catch (err) {
      console.error('Failed to update settlement:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleWhatsAppShare = () => {
    const encoded = generateWhatsAppSettlementMessage(
      formatMonthName(currentMonth),
      membersBreakdown,
      grandTotalSpend,
      language
    );
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-5 animate-fade-in pb-16">
      {/* Top Header & Month Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
        <div>
          <h2 className="text-xl md:text-2xl font-black text-zinc-100 tracking-tight flex items-center gap-2">
            <Calculator className="w-6 h-6 text-amber-400" />
            <span>{t('monthlySettlementTitle')}</span>
          </h2>
          <p className="text-xs text-zinc-400">
            {formatMonthName(currentMonth)} • {language === 'gu' ? 'ડેરી માલિકને સીધી ચુકવણી' : 'Direct payment to dairy owner'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-1.5 text-xs text-zinc-200">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <input
              type="month"
              value={currentMonth}
              onChange={(e) => setCurrentMonth(e.target.value)}
              className="bg-transparent text-xs text-amber-300 font-bold focus:outline-none cursor-pointer"
            />
          </div>

          <button
            onClick={handleWhatsAppShare}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-bold transition shadow-sm active:scale-95"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{t('shareWhatsApp')}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-zinc-700 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition active:scale-95"
          >
            <Printer className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'gu' ? 'પ્રિન્ટ' : 'Print'}</span>
          </button>
        </div>
      </div>

      {/* Printable Statement Header (visible during print) */}
      <div className="hidden print-only mb-6 text-black border-b pb-4">
        <h1 className="text-2xl font-black">ROOM DAIRY MANAGER – MONTHLY STATEMENT</h1>
        <p className="text-sm text-gray-600">Month: {formatMonthName(currentMonth)} | 5 Room Members Shared Dairy</p>
        <p className="text-xs text-gray-500 mt-1">Rule: Each member pays their exact calculated consumption directly to the dairy owner.</p>
      </div>

      {/* Direct Payment Notice */}
      <div className="rounded-2xl bg-amber-500/10 border border-amber-500/30 p-3.5 text-xs text-zinc-300 flex items-start gap-3">
        <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          {t('settlementNotice')}
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-zinc-900 border border-zinc-800 print-card">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1">
            {t('totalDairySpend')}
          </span>
          <div className="text-xl md:text-2xl font-black text-amber-400">
            ₹{grandTotalSpend.toFixed(2)}
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-zinc-900 border border-zinc-800 print-card">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1">
            🥛 {t('milk')}
          </span>
          <div className="text-xl font-black text-zinc-200">
            ₹{totalMilkSpend.toFixed(2)}
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-zinc-900 border border-zinc-800 print-card">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1">
            🍶 {t('chhaas')}
          </span>
          <div className="text-xl font-black text-zinc-200">
            ₹{totalChhaasSpend.toFixed(2)}
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-zinc-900 border border-zinc-800 print-card">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1">
            🥣 {t('curd')}
          </span>
          <div className="text-xl font-black text-zinc-200">
            ₹{totalCurdSpend.toFixed(2)}
          </div>
        </div>
      </div>

      {/* 5-Member Breakdown Cards */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
          <span>{language === 'gu' ? 'સભ્ય મુજબ હિસાબ (૫ સભ્યો)' : '5 Members Individual Breakdown'}</span>
          <span className="text-amber-400 font-extrabold">
            {language === 'gu' ? 'બાકી કુલ ડેરી રકમ:' : 'Total Due to Dairy:'} ₹{totalDueToDairy.toFixed(2)}
          </span>
        </h3>

        <div className="space-y-3">
          {membersBreakdown.map((member) => {
            const canonical = CANONICAL_MEMBERS.find((m) => m.id === member.memberId);
            const statusBadgeColor =
              member.status === 'paid'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : member.status === 'partially_paid'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40';

            const statusText =
              member.status === 'paid'
                ? t('paid_status')
                : member.status === 'partially_paid'
                ? t('partially_paid')
                : t('pending');

            return (
              <div
                key={member.memberId}
                className="p-4 md:p-5 rounded-3xl bg-zinc-900/90 border border-zinc-800 print-card space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-11 h-11 rounded-2xl flex items-center justify-center text-sm font-black text-zinc-950 shrink-0 shadow-md"
                      style={{ backgroundColor: canonical?.avatarColor || '#EAB308' }}
                    >
                      {member.memberName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm md:text-base font-extrabold text-zinc-100">
                          {language === 'gu' ? member.memberNameGu : member.memberName}
                        </h4>
                        {member.memberId === 'suresh' && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                            Admin
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-zinc-400">
                        {member.memberId === 'rajesh'
                          ? (language === 'gu' ? 'મહિને અંદાજે ૨૦ દિવસ રૂમ પર' : '~20 days in room')
                          : member.memberId === 'ashvin'
                          ? (language === 'gu' ? 'સવારની ચા નથી પીતા' : 'No morning tea')
                          : (language === 'gu' ? 'નિયમિત સભ્ય' : 'Regular member')}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-xs font-extrabold px-3 py-1 rounded-xl border ${statusBadgeColor}`}>
                      {statusText}
                    </span>

                    {/* Admin Status Update Button */}
                    {isAdmin && (
                      <button
                        onClick={() => handleOpenStatusModal(member)}
                        className="no-print p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-300 transition"
                        title={t('updateStatus')}
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Consumption Category Details */}
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 pt-1 border-t border-zinc-800/80 text-xs">
                  <div className="p-2 rounded-xl bg-zinc-950/60 border border-zinc-850">
                    <span className="text-zinc-500 text-[10px] block">🥛 {t('milk')}</span>
                    <span className="font-bold text-zinc-200">₹{member.milkAmount}</span>
                  </div>

                  <div className="p-2 rounded-xl bg-zinc-950/60 border border-zinc-850">
                    <span className="text-zinc-500 text-[10px] block">🍶 {t('chhaas')}</span>
                    <span className="font-bold text-zinc-200">₹{member.chhaasAmount}</span>
                  </div>

                  <div className="p-2 rounded-xl bg-zinc-950/60 border border-zinc-850">
                    <span className="text-zinc-500 text-[10px] block">🥣 {t('curd')}</span>
                    <span className="font-bold text-zinc-200">₹{member.curdAmount}</span>
                  </div>

                  <div className="p-2 rounded-xl bg-zinc-950/60 border border-zinc-850 col-span-3 sm:col-span-1">
                    <span className="text-zinc-500 text-[10px] block">📝 {t('udhar')}</span>
                    <span className="font-bold text-amber-300">₹{member.udharAmount}</span>
                  </div>
                </div>

                {/* Financial Bottom Summary */}
                <div className="flex items-center justify-between pt-2 border-t border-zinc-800/60 text-xs">
                  <div>
                    <span className="text-zinc-400">{t('totalShare')}: </span>
                    <span className="font-extrabold text-zinc-200">₹{member.totalAmount}</span>
                    {member.paidAmount > 0 && (
                      <span className="text-emerald-400 ml-2 font-semibold">
                        ({language === 'gu' ? 'ચૂકવેલ:' : 'Paid:'} ₹{member.paidAmount})
                      </span>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="text-zinc-400">{t('amountDue')}: </span>
                    <span className="text-sm md:text-base font-black text-amber-400">
                      ₹{member.dueAmount}
                    </span>
                  </div>
                </div>

                {member.settlementNotes && (
                  <p className="text-[11px] text-zinc-400 italic bg-zinc-950/60 p-2 rounded-xl">
                    "{member.settlementNotes}"
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Admin Status Update Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-zinc-900 border border-amber-500/40 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm md:text-base text-zinc-100 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>{selectedMember.memberName} - {t('updateStatus')}</span>
              </h3>
              <button
                onClick={() => setSelectedMember(null)}
                className="p-1 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-zinc-400 font-semibold mb-1">
                  {language === 'gu' ? 'સ્થિતિ પસંદ કરો' : 'Settlement Status'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'pending' as SettlementStatus, label: t('pending'), color: 'text-red-400' },
                    { id: 'partially_paid' as SettlementStatus, label: t('partially_paid'), color: 'text-amber-400' },
                    { id: 'paid' as SettlementStatus, label: t('paid_status'), color: 'text-emerald-400' },
                  ].map((s) => (
                    <button
                      type="button"
                      key={s.id}
                      onClick={() => {
                        setEditStatus(s.id);
                        if (s.id === 'paid') {
                          setEditPaidAmount(String(selectedMember.totalAmount));
                        }
                      }}
                      className={`py-2 px-1 rounded-xl border text-center font-bold text-xs ${
                        editStatus === s.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">
                  {language === 'gu' ? 'ડેરી વાળાને ચૂકવેલ રકમ (₹)' : 'Paid Amount to Dairy (₹)'}
                </label>
                <input
                  type="number"
                  value={editPaidAmount}
                  onChange={(e) => setEditPaidAmount(e.target.value)}
                  placeholder={`Total consumption: ₹${selectedMember.totalAmount}`}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-base font-bold text-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 font-semibold mb-1">
                  {language === 'gu' ? 'નોંધ' : 'Notes'}
                </label>
                <input
                  type="text"
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="e.g. Paid cash to dairy owner on 2nd"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-200 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setSelectedMember(null)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs hover:bg-zinc-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveStatus}
                disabled={isSaving}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 text-zinc-950 font-bold text-xs hover:bg-amber-400 disabled:opacity-50"
              >
                {isSaving ? 'Updating...' : 'Save Status'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
