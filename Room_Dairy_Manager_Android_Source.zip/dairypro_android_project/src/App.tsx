/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar, ActiveTab } from './components/Navbar';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { NotificationDrawer } from './components/NotificationDrawer';
import { DashboardView } from './views/DashboardView';
import { ExpensesView } from './views/ExpensesView';
import { AddEntryView } from './views/AddEntryView';
import { SettlementView } from './views/SettlementView';
import { MembersView } from './views/MembersView';
import { SettingsView } from './views/SettingsView';
import { AuthView } from './views/AuthView';
import { ExpenseItem, AppNotification, DairyCategory } from './types';
import { subscribeToAllExpenses } from './services/expenseService';
import { subscribeToNotifications } from './services/notificationService';

function MainApp() {
  const { currentUser, isPinLocked, isLoading } = useAuth();
  const { language } = useLanguage();

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [currentMonth, setCurrentMonth] = useState<string>(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  });

  const [expenses, setExpenses] = useState<ExpenseItem[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isNotifDrawerOpen, setIsNotifDrawerOpen] = useState<boolean>(false);
  const [quickCategory, setQuickCategory] = useState<DairyCategory>('milk');

  // Real-time Firestore subscriptions
  useEffect(() => {
    if (!currentUser) return;

    const unsubExpenses = subscribeToAllExpenses((items) => {
      setExpenses(items);
    });

    const unsubNotifs = subscribeToNotifications((items) => {
      setNotifications(items);
    });

    return () => {
      unsubExpenses();
      unsubNotifs();
    };
  }, [currentUser]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center text-zinc-100 p-4">
        <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-3xl mb-4 gold-glow animate-pulse">
          🥛
        </div>
        <h2 className="font-extrabold text-amber-400 text-base">
          {language === 'gu' ? 'રૂમ ડેરી મેનેજર શરૂ થઈ રહ્યું છે...' : 'Loading Room Dairy Manager...'}
        </h2>
        <p className="text-xs text-zinc-500 mt-1">Connecting to room-fdba7</p>
      </div>
    );
  }

  // Not authenticated or session locked with PIN
  if (!currentUser || isPinLocked) {
    return <AuthView />;
  }

  const handleQuickAdd = (category: DairyCategory) => {
    setQuickCategory(category);
    setActiveTab('add');
  };

  const unreadCount = notifications.filter(
    (n) => !n.readBy.includes(currentUser.email || '')
  ).length;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unreadCount={unreadCount}
        onOpenNotifications={() => setIsNotifDrawerOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 pt-4 md:pt-6">
        {/* In-App PWA Install Banner */}
        <PWAInstallBanner />

        {activeTab === 'dashboard' && (
          <DashboardView
            expenses={expenses}
            currentMonth={currentMonth}
            setCurrentMonth={setCurrentMonth}
            setActiveTab={setActiveTab}
            onQuickAdd={handleQuickAdd}
          />
        )}

        {activeTab === 'expenses' && (
          <ExpensesView
            expenses={expenses}
            currentMonth={currentMonth}
            setCurrentMonth={setCurrentMonth}
          />
        )}

        {activeTab === 'add' && (
          <AddEntryView
            initialCategory={quickCategory}
            onSuccess={() => setActiveTab('expenses')}
          />
        )}

        {activeTab === 'settlement' && (
          <SettlementView
            expenses={expenses}
            currentMonth={currentMonth}
            setCurrentMonth={setCurrentMonth}
          />
        )}

        {activeTab === 'members' && (
          <MembersView
            expenses={expenses}
            currentMonth={currentMonth}
          />
        )}

        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Notification Drawer */}
      <NotificationDrawer
        isOpen={isNotifDrawerOpen}
        onClose={() => setIsNotifDrawerOpen(false)}
        notifications={notifications}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MainApp />
      </AuthProvider>
    </LanguageProvider>
  );
}
