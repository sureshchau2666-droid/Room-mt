/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { CANONICAL_MEMBERS, ADMIN_EMAIL } from '../types';
import { 
  resolveFirebaseConfig, 
  saveCustomFirebaseConfig, 
  isFirebaseConfigured, 
  FirebaseClientConfig 
} from '../firebase/config';
import { 
  Lock, 
  Mail, 
  KeyRound, 
  User, 
  AlertCircle, 
  CheckCircle, 
  Languages, 
  Database, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles 
} from 'lucide-react';

export const AuthView: React.FC = () => {
  const { t, language, setLanguage } = useLanguage();
  const { 
    loginWithEmail, 
    registerMember, 
    unlockWithPin, 
    sendResetEmail, 
    isPinLocked, 
    hasPinConfigured, 
    currentMember,
    isFirebaseReady,
    reloadFirebase
  } = useAuth();

  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot' | 'pin'>(() => {
    return isPinLocked && hasPinConfigured ? 'pin' : 'login';
  });

  // Form states
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [unlockPin, setUnlockPin] = useState<string>('');
  
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Missing API Key Config UI
  const [showConfigHelper, setShowConfigHelper] = useState<boolean>(!isFirebaseConfigured());
  const [inputApiKey, setInputApiKey] = useState<string>('');
  const [inputAppId, setInputAppId] = useState<string>('');

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputApiKey || inputApiKey.trim().length < 10) {
      setErrorMsg('Please provide a valid Firebase Web API key.');
      return;
    }
    const cfg = resolveFirebaseConfig();
    saveCustomFirebaseConfig({
      ...cfg,
      apiKey: inputApiKey.trim(),
      appId: inputAppId.trim(),
    });
    reloadFirebase();
    setShowConfigHelper(false);
    setErrorMsg('');
    setSuccessMsg('Firebase credentials connected! You may now sign in.');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      await loginWithEmail(email, password);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        setErrorMsg(t('invalidCredentials'));
      } else {
        setErrorMsg(err.message || 'Login failed. Please verify credentials.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!/^\d{4}$/.test(pin)) {
      setErrorMsg(t('pinInvalid'));
      return;
    }

    if (pin !== confirmPin) {
      setErrorMsg(t('pinMismatch'));
      return;
    }

    setIsSubmitting(true);
    try {
      await registerMember(name, email, password, pin);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/email-already-in-use') {
        setErrorMsg('This email is already registered. Please sign in instead.');
      } else {
        setErrorMsg(err.message || 'Registration failed.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePinUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const res = await unlockWithPin(unlockPin);
      if (!res.success) {
        setErrorMsg(res.error || 'Incorrect PIN');
        setUnlockPin('');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'PIN unlock failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!email) {
      setErrorMsg('Please enter your registered email address.');
      return;
    }

    setIsSubmitting(true);
    try {
      await sendResetEmail(email);
      setSuccessMsg(t('resetEmailSent'));
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to send password reset email.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col justify-center px-4 py-8">
      {/* Background radial glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-md w-full mx-auto relative z-10 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex w-16 h-16 rounded-3xl bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 shadow-xl shadow-amber-500/20 mb-1">
            <div className="w-full h-full bg-zinc-950 rounded-[22px] flex items-center justify-center text-3xl">
              🥛
            </div>
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-amber-400 tracking-tight">
            {language === 'gu' ? 'રૂમ ડેરી મેનેજર' : 'Room Dairy Manager'}
          </h1>
          <p className="text-xs text-zinc-400">
            {language === 'gu'
              ? '૫ સભ્યોનો સુરક્ષિત ડેરી હિસાબ (દૂધ, છાશ, દહીં)'
              : 'Production 5-Member Shared Dairy Tracker'}
          </p>
        </div>

        {/* Language switch pill */}
        <div className="flex justify-center">
          <button
            onClick={() => setLanguage(language === 'gu' ? 'en' : 'gu')}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-zinc-800 bg-zinc-900 text-xs font-semibold text-amber-300 hover:bg-zinc-800 transition"
          >
            <Languages className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'gu' ? 'English માં જુઓ' : 'Switch to ગુજરાતી'}</span>
          </button>
        </div>

        {/* Firebase Config Notice & Setup Card if needed */}
        {showConfigHelper && (
          <div className="rounded-3xl bg-zinc-900 border border-amber-500/40 p-5 space-y-3 shadow-xl">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
              <Database className="w-4 h-4" />
              <span>Connect to Existing Project (room-fdba7)</span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Your Firebase project <strong>room-fdba7</strong> is connected. To authorize web sign-ins directly from the browser, provide your Firebase Web API Key:
            </p>
            <form onSubmit={handleSaveConfig} className="space-y-2.5 text-xs">
              <div>
                <label className="text-zinc-400 block mb-1">Web API Key (apiKey):</label>
                <input
                  type="text"
                  value={inputApiKey}
                  onChange={(e) => setInputApiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition"
              >
                Save & Initialize room-fdba7
              </button>
            </form>
          </div>
        )}

        {/* Feedback messages */}
        {errorMsg && (
          <div className="p-3.5 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs font-bold flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-start gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* PIN Unlock Mode */}
        {authMode === 'pin' && (
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-6 space-y-4 shadow-xl">
            <div className="text-center space-y-1">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-400 flex items-center justify-center mx-auto mb-2">
                <KeyRound className="w-6 h-6" />
              </div>
              <h2 className="text-base font-extrabold text-zinc-100">{t('pinUnlockTitle')}</h2>
              <p className="text-xs text-zinc-400">{t('enterPinToUnlock')}</p>
            </div>

            <form onSubmit={handlePinUnlock} className="space-y-4">
              <input
                type="password"
                maxLength={4}
                pattern="\d{4}"
                inputMode="numeric"
                autoFocus
                value={unlockPin}
                onChange={(e) => setUnlockPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="••••"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-3 text-center text-3xl font-black tracking-[0.5em] text-amber-400 focus:outline-none focus:border-amber-500"
                required
              />

              <button
                type="submit"
                disabled={isSubmitting || unlockPin.length !== 4}
                className="w-full py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs uppercase tracking-wider transition disabled:opacity-50"
              >
                {isSubmitting ? 'Unlocking...' : t('unlockWithPin')}
              </button>
            </form>

            <button
              onClick={() => setAuthMode('login')}
              className="w-full text-center text-xs text-zinc-400 hover:text-amber-300 transition"
            >
              {t('loginWithPasswordInstead')}
            </button>
          </div>
        )}

        {/* Email + Password Sign In Mode */}
        {authMode === 'login' && (
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h2 className="text-sm font-bold text-zinc-100">{t('loginTitle')}</h2>
              <span className="text-[11px] text-zinc-500">Firebase Auth</span>
            </div>

            <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
              <div>
                <label className="text-zinc-400 font-semibold block mb-1">{t('email')}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="sureshchau2666@gmail.com"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-zinc-400 font-semibold">{t('password')}</label>
                  <button
                    type="button"
                    onClick={() => setAuthMode('forgot')}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    {t('forgotPasswordLink')}
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs uppercase tracking-wider transition disabled:opacity-50 mt-2"
              >
                {isSubmitting ? 'Signing in...' : t('loginButton')}
              </button>
            </form>

            <div className="pt-2 text-center">
              <button
                onClick={() => setAuthMode('register')}
                className="text-xs text-zinc-400 hover:text-amber-300 transition"
              >
                {t('noAccount')}{' '}
                <strong className="text-amber-400 underline">{t('registerTitle')}</strong>
              </button>
            </div>
          </div>
        )}

        {/* Member Registration Mode */}
        {authMode === 'register' && (
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-6 space-y-4 shadow-xl">
            <div className="border-b border-zinc-800 pb-3">
              <h2 className="text-sm font-bold text-zinc-100">{t('registerTitle')}</h2>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                {language === 'gu'
                  ? 'રૂમના ૫ સભ્યોમાંથી તમારું નામ પસંદ કરી રજીસ્ટર કરો'
                  : 'Select your member profile to complete registration'}
              </p>
            </div>

            <form onSubmit={handleRegister} className="space-y-3.5 text-xs">
              <div>
                <label className="text-zinc-400 font-semibold block mb-1">
                  {t('selectYourMemberName')}
                </label>
                <select
                  value={name}
                  onChange={(e) => {
                    const selName = e.target.value;
                    setName(selName);
                    const selected = CANONICAL_MEMBERS.find((m) => m.name === selName);
                    if (selected) {
                      if (selected.id === 'suresh') {
                        setEmail('sureshchau2666@gmail.com');
                      } else if (!email || email === 'sureshchau2666@gmail.com') {
                        setEmail(selected.email);
                      }
                    }
                  }}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs font-bold text-amber-300 focus:outline-none focus:border-amber-500"
                  required
                >
                  <option value="">-- Choose Member (5 Approved Only) --</option>
                  {CANONICAL_MEMBERS.map((m) => (
                    <option key={m.id} value={m.name}>
                      {language === 'gu' ? m.nameGu : m.name} ({m.id === 'suresh' ? 'ADMIN' : 'MEMBER'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-zinc-400 font-semibold block mb-1">
                  {t('email')} {name === 'Suresh' && <span className="text-amber-400 font-bold">(Designated Admin Email)</span>}
                </label>
                <input
                  type="email"
                  value={email}
                  readOnly={name === 'Suresh'}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@gmail.com"
                  className={`w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500 ${
                    name === 'Suresh' ? 'opacity-80 bg-zinc-900 cursor-not-allowed font-mono text-amber-300' : ''
                  }`}
                  required
                />
              </div>

              <div>
                <label className="text-zinc-400 font-semibold block mb-1">{t('password')}</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
                  required
                  minLength={6}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-zinc-400 font-semibold block mb-1">
                    {language === 'gu' ? '૪-અંકનો PIN' : '4-Digit PIN'}
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    pattern="\d{4}"
                    inputMode="numeric"
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    placeholder="••••"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-center text-sm font-bold text-amber-400 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-zinc-400 font-semibold block mb-1">
                    {language === 'gu' ? 'PIN ફરી લખો' : 'Confirm PIN'}
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    pattern="\d{4}"
                    inputMode="numeric"
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    placeholder="••••"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-center text-sm font-bold text-amber-400 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs uppercase tracking-wider transition disabled:opacity-50 mt-2"
              >
                {isSubmitting ? 'Registering...' : t('registerButton')}
              </button>
            </form>

            <div className="pt-2 text-center">
              <button
                onClick={() => setAuthMode('login')}
                className="text-xs text-zinc-400 hover:text-amber-300 transition"
              >
                {t('alreadyAccount')}
              </button>
            </div>
          </div>
        )}

        {/* Forgot Password Mode */}
        {authMode === 'forgot' && (
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-6 space-y-4 shadow-xl">
            <h2 className="text-sm font-bold text-zinc-100">{t('forgotPasswordTitle')}</h2>
            <form onSubmit={handleForgotPassword} className="space-y-3.5 text-xs">
              <div>
                <label className="text-zinc-400 font-semibold block mb-1">{t('email')}</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@gmail.com"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs uppercase tracking-wider transition disabled:opacity-50"
              >
                {isSubmitting ? 'Sending...' : t('sendResetLink')}
              </button>

              <button
                type="button"
                onClick={() => setAuthMode('login')}
                className="w-full text-center text-xs text-zinc-400 hover:text-amber-300 pt-2"
              >
                {t('backToLogin')}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
