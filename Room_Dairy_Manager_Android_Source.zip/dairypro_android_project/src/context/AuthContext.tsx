/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  onSnapshot 
} from 'firebase/firestore';
import { auth, db, isFirebaseConfigured, initFirebase } from '../firebase/config';
import { RoomMember, MemberPrivateSecurity, CANONICAL_MEMBERS, ADMIN_EMAIL } from '../types';
import { hashPin, generateSalt, getPinLockoutState, recordFailedPinAttempt, resetPinAttempts } from '../utils/security';

interface AuthContextType {
  currentUser: User | null;
  currentMember: RoomMember | null;
  isAdmin: boolean;
  isLoading: boolean;
  isFirebaseReady: boolean;
  isPinLocked: boolean;
  hasPinConfigured: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerMember: (name: string, email: string, pass: string, pin: string) => Promise<void>;
  unlockWithPin: (pin: string) => Promise<{ success: boolean; error?: string }>;
  lockSession: () => void;
  updateMemberPin: (newPin: string) => Promise<void>;
  sendResetEmail: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  reloadFirebase: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const PIN_SESSION_LOCKED_KEY = 'rdm_session_locked';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentMember, setCurrentMember] = useState<RoomMember | null>(null);
  const [privateSecurity, setPrivateSecurity] = useState<MemberPrivateSecurity | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isFirebaseReady, setIsFirebaseReady] = useState<boolean>(isFirebaseConfigured());
  const [isPinLocked, setIsPinLocked] = useState<boolean>(() => {
    return localStorage.getItem(PIN_SESSION_LOCKED_KEY) === 'true';
  });

  const reloadFirebase = () => {
    const initialized = initFirebase();
    setIsFirebaseReady(isFirebaseConfigured() && initialized.auth !== null);
  };

  useEffect(() => {
    if (!auth || !db) {
      setIsLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user && user.email) {
        const userEmail = user.email.toLowerCase();
        
        // Match with canonical members
        const canonical = CANONICAL_MEMBERS.find(
          (m) => m.email.toLowerCase() === userEmail || (userEmail === ADMIN_EMAIL && m.id === 'suresh')
        );

        const memberId = canonical ? canonical.id : user.uid;
        const firestore = db;
        if (!firestore) return;

        // 1. Listen to public member profile (safe: contains NO pinHash/pinSalt)
        const memberRef = doc(firestore, 'members', memberId);
        const unsubDoc = onSnapshot(memberRef, async (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data() as RoomMember;
            setCurrentMember({
              ...data,
              id: memberId,
              role: userEmail === ADMIN_EMAIL ? 'admin' : 'member',
              email: user.email || '',
            });
          } else {
            // First time this member doc is accessed: initialize from canonical
            const initialMember: RoomMember = {
              id: memberId,
              name: canonical ? canonical.name : (user.displayName || 'Member'),
              nameGu: canonical ? canonical.nameGu : (user.displayName || 'સભ્ય'),
              email: user.email || '',
              role: userEmail === ADMIN_EMAIL ? 'admin' : 'member',
              active: true,
              avatarColor: canonical ? canonical.avatarColor : '#EAB308',
              uid: user.uid,
              lastLogin: Date.now(),
              hasPinConfigured: false,
            };
            try {
              await setDoc(memberRef, initialMember, { merge: true });
              setCurrentMember(initialMember);
            } catch (err) {
              console.warn('Could not auto-write member profile:', err);
              setCurrentMember(initialMember);
            }
          }
          setIsLoading(false);
        }, (err) => {
          console.error('Error listening to member document:', err);
          setIsLoading(false);
        });

        // 2. Listen to PRIVATE security document (ONLY accessible by this user)
        const securityRef = doc(firestore, 'members', memberId, 'private', 'security');
        const unsubSec = onSnapshot(securityRef, (secSnap) => {
          if (secSnap.exists()) {
            setPrivateSecurity(secSnap.data() as MemberPrivateSecurity);
          } else {
            setPrivateSecurity(null);
          }
        }, (err) => {
          console.warn('Error reading private security document:', err);
        });

        return () => {
          unsubDoc();
          unsubSec();
        };
      } else {
        setCurrentMember(null);
        setPrivateSecurity(null);
        setIsLoading(false);
      }
    });

    return () => unsubscribe();
  }, [isFirebaseReady]);

  const loginWithEmail = async (email: string, pass: string) => {
    if (!auth) throw new Error('Firebase Auth is not initialized. Please verify room-fdba7 Web API key.');
    await signInWithEmailAndPassword(auth, email.trim(), pass);
    setIsPinLocked(false);
    localStorage.removeItem(PIN_SESSION_LOCKED_KEY);
    resetPinAttempts();
  };

  const registerMember = async (name: string, email: string, pass: string, pin: string) => {
    const firestore = db;
    if (!auth || !firestore) throw new Error('Firebase Auth/Firestore not initialized.');
    
    // Strict Validation: Only the 5 approved members are authorized
    const canonical = CANONICAL_MEMBERS.find((m) => m.name.toLowerCase() === name.trim().toLowerCase());
    if (!canonical) {
      throw new Error('Only the five designated room members (Suresh, Ashvin, Ramesh, Prakash, Rajesh) can register.');
    }

    const cleanEmail = email.trim().toLowerCase();
    if (canonical.id === 'suresh' && cleanEmail !== ADMIN_EMAIL) {
      throw new Error(`Suresh must register with designated admin email: ${ADMIN_EMAIL}`);
    }

    // Check if this member profile is already bound to an active user account
    const memberDocSnap = await getDoc(doc(firestore, 'members', canonical.id));
    if (memberDocSnap.exists()) {
      const existingData = memberDocSnap.data() as RoomMember;
      if (existingData.uid && existingData.email && existingData.email !== cleanEmail) {
        throw new Error(`Member slot "${canonical.name}" is already registered. Please sign in.`);
      }
    }

    // Validate PIN format (4 digits)
    if (!/^\d{4}$/.test(pin)) {
      throw new Error('PIN must be exactly 4 digits.');
    }

    const cred = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
    const user = cred.user;

    const salt = generateSalt();
    const hashed = await hashPin(pin, salt);

    const memberId = canonical.id;

    // 1. Write public profile to `members/{memberId}` (WITHOUT PIN)
    const publicMember: RoomMember = {
      id: memberId,
      name: canonical.name,
      nameGu: canonical.nameGu,
      email: cleanEmail,
      role: cleanEmail === ADMIN_EMAIL ? 'admin' : 'member',
      active: true,
      avatarColor: canonical.avatarColor,
      uid: user.uid,
      lastLogin: Date.now(),
      hasPinConfigured: true,
    };
    await setDoc(doc(firestore, 'members', memberId), publicMember, { merge: true });

    // 2. Write private security record to isolated subcollection `members/{memberId}/private/security`
    const privateSec: MemberPrivateSecurity = {
      memberId,
      pinHash: hashed,
      pinSalt: salt,
      updatedAt: Date.now(),
    };
    await setDoc(doc(firestore, 'members', memberId, 'private', 'security'), privateSec);

    setCurrentMember(publicMember);
    setPrivateSecurity(privateSec);
    setIsPinLocked(false);
    localStorage.removeItem(PIN_SESSION_LOCKED_KEY);
  };

  const unlockWithPin = async (enteredPin: string): Promise<{ success: boolean; error?: string }> => {
    const lockout = getPinLockoutState();
    if (lockout.isLocked) {
      return { success: false, error: `Account locked. Please wait ${lockout.remainingSeconds} seconds.` };
    }

    if (!privateSecurity || !privateSecurity.pinHash || !privateSecurity.pinSalt) {
      return { success: false, error: 'PIN is not configured for this account. Please use password login.' };
    }

    const computedHash = await hashPin(enteredPin, privateSecurity.pinSalt);
    if (computedHash === privateSecurity.pinHash) {
      resetPinAttempts();
      setIsPinLocked(false);
      localStorage.removeItem(PIN_SESSION_LOCKED_KEY);
      return { success: true };
    } else {
      const state = recordFailedPinAttempt();
      if (state.isLocked) {
        return { success: false, error: `Too many failed attempts. Locked for ${state.remainingSeconds} seconds.` };
      }
      return { success: false, error: `Incorrect PIN. ${state.attemptsLeft} attempts remaining.` };
    }
  };

  const lockSession = () => {
    setIsPinLocked(true);
    localStorage.setItem(PIN_SESSION_LOCKED_KEY, 'true');
  };

  const updateMemberPin = async (newPin: string): Promise<void> => {
    const firestore = db;
    if (!firestore || !currentMember || !currentUser) throw new Error('Firestore or member not active');
    if (!/^\d{4}$/.test(newPin)) throw new Error('PIN must be exactly 4 digits');

    const salt = generateSalt();
    const hashed = await hashPin(newPin, salt);

    // Save to private subcollection isolated from other members
    const privateSec: MemberPrivateSecurity = {
      memberId: currentMember.id,
      pinHash: hashed,
      pinSalt: salt,
      updatedAt: Date.now(),
    };
    await setDoc(doc(firestore, 'members', currentMember.id, 'private', 'security'), privateSec);

    // Update public flag
    await setDoc(
      doc(firestore, 'members', currentMember.id),
      { hasPinConfigured: true, lastLogin: Date.now() },
      { merge: true }
    );

    setPrivateSecurity(privateSec);
  };

  const sendResetEmail = async (email: string) => {
    if (!auth) throw new Error('Firebase Auth not initialized.');
    await sendPasswordResetEmail(auth, email.trim());
  };

  const logout = async () => {
    if (auth) {
      await firebaseSignOut(auth);
    }
    setCurrentUser(null);
    setCurrentMember(null);
    setPrivateSecurity(null);
    setIsPinLocked(false);
    localStorage.removeItem(PIN_SESSION_LOCKED_KEY);
  };

  const isAdmin = Boolean(
    currentUser &&
    currentUser.email &&
    currentUser.email.toLowerCase() === ADMIN_EMAIL
  );

  const hasPinConfigured = Boolean(currentMember?.hasPinConfigured || privateSecurity?.pinHash);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentMember,
        isAdmin,
        isLoading,
        isFirebaseReady,
        isPinLocked,
        hasPinConfigured,
        loginWithEmail,
        registerMember,
        unlockWithPin,
        lockSession,
        updateMemberPin,
        sendResetEmail,
        logout,
        reloadFirebase,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
