/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { collection, addDoc, query, orderBy, limit, onSnapshot, doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db } from '../firebase/config';
import { AppNotification } from '../types';

export interface CreateNotificationPayload {
  title: string;
  titleGu: string;
  body: string;
  bodyGu: string;
  category: 'expense_added' | 'expense_edited' | 'expense_deleted' | 'settlement_updated' | 'system';
}

export async function createNotification(payload: CreateNotificationPayload): Promise<void> {
  if (!db) return;

  try {
    await addDoc(collection(db, 'notifications'), {
      ...payload,
      createdAt: Date.now(),
      readBy: [],
    });

    // Also trigger browser notification if permission granted
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(payload.title, {
          body: payload.body,
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
        });
      } catch {
        // Ignore mobile browser service-worker-only notification error
      }
    }
  } catch (err) {
    console.warn('Could not post notification:', err);
  }
}

export function subscribeToNotifications(
  callback: (notifications: AppNotification[]) => void
): () => void {
  if (!db) {
    callback([]);
    return () => {};
  }

  const q = query(collection(db, 'notifications'), orderBy('createdAt', 'desc'), limit(25));

  return onSnapshot(q, (snapshot) => {
    const list: AppNotification[] = snapshot.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        title: data.title || '',
        titleGu: data.titleGu || data.title || '',
        body: data.body || '',
        bodyGu: data.bodyGu || data.body || '',
        category: data.category || 'system',
        createdAt: data.createdAt || 0,
        readBy: data.readBy || [],
      };
    });
    callback(list);
  }, (err) => {
    console.error('Notification subscription error:', err);
  });
}

export async function markNotificationAsRead(id: string, userIdentifier: string): Promise<void> {
  if (!db) return;
  try {
    await updateDoc(doc(db, 'notifications', id), {
      readBy: arrayUnion(userIdentifier),
    });
  } catch (err) {
    console.warn('Could not mark notification read:', err);
  }
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission === 'granted') {
    return true;
  }

  if (Notification.permission !== 'denied') {
    const perm = await Notification.requestPermission();
    return perm === 'granted';
  }

  return false;
}
