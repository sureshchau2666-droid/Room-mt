/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  Timestamp,
  getDocs
} from 'firebase/firestore';
import { db, auth } from '../firebase/config';
import { ExpenseItem, DairyCategory, PaymentType, ADMIN_EMAIL } from '../types';
import { createNotification } from './notificationService';

export interface NewExpensePayload {
  date: string; // YYYY-MM-DD
  category: DairyCategory;
  amount: number;
  paidBy: string;
  paymentType: PaymentType;
  usedBy: string[];
  notes?: string;
  createdBy: string;
  createdByName: string;
}

// In-memory duplicate preventer within 10 seconds
const recentSubmissions: { key: string; time: number }[] = [];

export async function addExpense(payload: NewExpensePayload): Promise<string> {
  if (!db) throw new Error('Firestore is not initialized.');

  if (!payload.amount || payload.amount <= 0) {
    throw new Error('Expense amount must be greater than 0.');
  }

  if (!payload.usedBy || payload.usedBy.length === 0) {
    throw new Error('At least one member must be selected as a consumer.');
  }

  // Duplicate entry prevention
  const submissionKey = `${payload.date}_${payload.category}_${payload.amount}_${payload.paidBy}_${payload.usedBy.sort().join(',')}`;
  const now = Date.now();
  const duplicate = recentSubmissions.find(
    (item) => item.key === submissionKey && now - item.time < 10000
  );

  if (duplicate) {
    throw new Error('Duplicate entry detected. This expense was already recorded a few moments ago.');
  }

  recentSubmissions.push({ key: submissionKey, time: now });
  // Clean old entries
  if (recentSubmissions.length > 20) {
    recentSubmissions.shift();
  }

  const splitAmount = Number((payload.amount / payload.usedBy.length).toFixed(2));

  const expenseData = {
    date: payload.date,
    category: payload.category,
    amount: Number(payload.amount),
    paidBy: payload.paidBy,
    paymentType: payload.paymentType,
    usedBy: payload.usedBy,
    splitAmountPerPerson: splitAmount,
    notes: payload.notes ? payload.notes.trim() : '',
    createdBy: payload.createdBy,
    createdByName: payload.createdByName,
    createdAt: Date.now(),
  };

  const docRef = await addDoc(collection(db, 'expenses'), expenseData);

  // Send real-time notification to all members
  const categoryNamesEn: Record<DairyCategory, string> = {
    milk: 'Milk',
    chhaas: 'Chhaas',
    curd: 'Curd',
  };
  const categoryNamesGu: Record<DairyCategory, string> = {
    milk: 'દૂધ',
    chhaas: 'છાશ',
    curd: 'દહીં',
  };

  const catEn = categoryNamesEn[payload.category];
  const catGu = categoryNamesGu[payload.category];

  await createNotification({
    title: `New Dairy Expense: ₹${payload.amount} for ${catEn}`,
    titleGu: `નવો ડેરી ખર્ચ: ₹${payload.amount} (${catGu})`,
    body: `Added by ${payload.createdByName}. Split among ${payload.usedBy.length} members (₹${splitAmount} each).`,
    bodyGu: `${payload.createdByName} દ્વારા ઉમેરાયો. ${payload.usedBy.length} સભ્યો વચ્ચે ભાગ (માથાદીઠ ₹${splitAmount}).`,
    category: 'expense_added',
  });

  return docRef.id;
}

export async function updateExpense(
  id: string,
  payload: Partial<NewExpensePayload>,
  adminName: string
): Promise<void> {
  if (!db) throw new Error('Firestore is not initialized.');

  // Strict Admin Authorization Check
  if (!auth?.currentUser?.email || auth.currentUser.email.toLowerCase() !== ADMIN_EMAIL) {
    throw new Error('Unauthorized: Only Suresh (Admin) can modify expenses.');
  }

  const updateData: Record<string, any> = {
    updatedAt: Date.now(),
    updatedBy: adminName,
  };

  if (payload.amount !== undefined) updateData.amount = Number(payload.amount);
  if (payload.category !== undefined) updateData.category = payload.category;
  if (payload.date !== undefined) updateData.date = payload.date;
  if (payload.paidBy !== undefined) updateData.paidBy = payload.paidBy;
  if (payload.paymentType !== undefined) updateData.paymentType = payload.paymentType;
  if (payload.usedBy !== undefined) {
    updateData.usedBy = payload.usedBy;
    const amount = payload.amount !== undefined ? Number(payload.amount) : 0;
    if (amount > 0 && payload.usedBy.length > 0) {
      updateData.splitAmountPerPerson = Number((amount / payload.usedBy.length).toFixed(2));
    }
  }
  if (payload.notes !== undefined) updateData.notes = payload.notes.trim();

  await updateDoc(doc(db, 'expenses', id), updateData);
}

export async function deleteExpense(id: string, adminName: string): Promise<void> {
  if (!db) throw new Error('Firestore is not initialized.');

  // Strict Admin Authorization Check
  if (!auth?.currentUser?.email || auth.currentUser.email.toLowerCase() !== ADMIN_EMAIL) {
    throw new Error('Unauthorized: Only Suresh (Admin) can delete expenses.');
  }

  await deleteDoc(doc(db, 'expenses', id));

  await createNotification({
    title: `Dairy Entry Removed`,
    titleGu: `ડેરી એન્ટ્રી કાઢી નાખી`,
    body: `Admin ${adminName} removed an expense entry.`,
    bodyGu: `એડમિન ${adminName} દ્વારા એક ડેરી એન્ટ્રી હટાવવામાં આવી.`,
    category: 'expense_deleted',
  });
}

export function subscribeToMonthlyExpenses(
  month: string, // YYYY-MM
  callback: (expenses: ExpenseItem[]) => void,
  onError?: (error: Error) => void
): () => void {
  if (!db) {
    callback([]);
    return () => {};
  }

  const startDate = `${month}-01`;
  const endDate = `${month}-31`;

  const q = query(
    collection(db, 'expenses'),
    where('date', '>=', startDate),
    where('date', '<=', endDate),
    orderBy('date', 'desc')
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: ExpenseItem[] = snapshot.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          date: data.date,
          category: data.category,
          amount: data.amount,
          paidBy: data.paidBy,
          paymentType: data.paymentType,
          usedBy: data.usedBy || [],
          splitAmountPerPerson: data.splitAmountPerPerson || 0,
          notes: data.notes || '',
          createdBy: data.createdBy || '',
          createdByName: data.createdByName || 'Member',
          createdAt: data.createdAt || 0,
          updatedAt: data.updatedAt,
        };
      });
      callback(items);
    },
    (err) => {
      console.error('Error fetching monthly expenses:', err);
      if (onError) onError(err);
    }
  );
}

export function subscribeToAllExpenses(
  callback: (expenses: ExpenseItem[]) => void,
  onError?: (error: Error) => void
): () => void {
  if (!db) {
    callback([]);
    return () => {};
  }

  const q = query(collection(db, 'expenses'), orderBy('date', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: ExpenseItem[] = snapshot.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          date: data.date,
          category: data.category,
          amount: data.amount,
          paidBy: data.paidBy,
          paymentType: data.paymentType,
          usedBy: data.usedBy || [],
          splitAmountPerPerson: data.splitAmountPerPerson || 0,
          notes: data.notes || '',
          createdBy: data.createdBy || '',
          createdByName: data.createdByName || 'Member',
          createdAt: data.createdAt || 0,
          updatedAt: data.updatedAt,
        };
      });
      callback(items);
    },
    (err) => {
      console.error('Error in subscribeToAllExpenses:', err);
      if (onError) onError(err);
    }
  );
}
